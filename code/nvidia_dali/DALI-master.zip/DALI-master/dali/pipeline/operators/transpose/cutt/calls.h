#if MAX_REG_STORAGE >= 1
CALL(1);
#endif
#if MAX_REG_STORAGE >= 2
CALL(2);
#endif
#if MAX_REG_STORAGE >= 3
CALL(3);
#endif
#if MAX_REG_STORAGE >= 4
CALL(4);
#endif
#if MAX_REG_STORAGE >= 5
CALL(5);
#endif
#if MAX_REG_STORAGE >= 6
CALL(6);
#endif
#if MAX_REG_STORAGE >= 7
CALL(7);
#endif
#if MAX_REG_STORAGE >= 8
CALL(8);
#endif
#if MAX_REG_STORAGE >= 9
CALL(9);
#endif
#if MAX_REG_STORAGE >= 10
CALL(10);
#endif

#if MAX_REG_STORAGE >= 11
CALL(11);
#endif
#if MAX_REG_STORAGE >= 12
CALL(12);
#endif
#if MAX_REG_STORAGE >= 13
CALL(13);
#endif
#if MAX_REG_STORAGE >= 14
CALL(14);
#endif
#if MAX_REG_STORAGE >= 15
CALL(15);
#endif
#if MAX_REG_STORAGE >= 16
CALL(16);
#endif
#if MAX_REG_STORAGE >= 17
CALL(17);
#endif
#if MAX_REG_STORAGE >= 18
CALL(18);
#endif
#if MAX_REG_STORAGE >= 19
CALL(19);
#endif
#if MAX_REG_STORAGE >= 20
CALL(20);
#endif

#if MAX_REG_STORAGE >= 21
CALL(21);
#endif
#if MAX_REG_STORAGE >= 22
CALL(22);
#endif
#if MAX_REG_STORAGE >= 23
CALL(23);
#endif
#if MAX_REG_STORAGE >= 24
CALL(24);
#endif
#if MAX_REG_STORAGE >= 25
CALL(25);
#endif
#if MAX_REG_STORAGE >= 26
CALL(26);
#endif
#if MAX_REG_STORAGE >= 27
CALL(27);
#endif
#if MAX_REG_STORAGE >= 28
CALL(28);
#endif
#if MAX_REG_STORAGE >= 29
CALL(29);
#endif
#if MAX_REG_STORAGE >= 30
CALL(30);
#endif
