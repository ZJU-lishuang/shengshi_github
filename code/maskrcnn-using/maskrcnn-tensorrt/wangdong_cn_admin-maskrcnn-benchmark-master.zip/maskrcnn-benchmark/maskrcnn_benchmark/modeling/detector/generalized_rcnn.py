# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
"""
Implements the Generalized R-CNN framework
"""


from torch import nn

from maskrcnn_benchmark.structures.image_list import to_image_list

from ..backbone import build_backbone
from ..rpn.rpn import build_rpn
from ..roi_heads.roi_heads import build_roi_heads
#import pytorch2caffe.pytorch_to_caffe  as pytorch_to_caffe
from time import time

class GeneralizedRCNN(nn.Module):
    """
    Main class for Generalized R-CNN. Currently supports boxes and masks.
    It consists of three main parts:
    - backbone
    - rpn
    - heads: takes the features + the proposals from the RPN and computes
        detections / masks from it.
    """

    def __init__(self, cfg):
        super(GeneralizedRCNN, self).__init__()

        self.backbone = build_backbone(cfg)
        self.rpn = build_rpn(cfg, self.backbone.out_channels)
        self.roi_heads = build_roi_heads(cfg, self.backbone.out_channels)
        self.EXPORT_ONNX = cfg.TEST.EXPORT_ONNX
        self.USING_TensorRT = cfg.TEST.USING_TensorRT
        self.cfg = cfg

    def forward(self, images, targets=None):
        """
        Arguments:
            images (list[Tensor] or ImageList): images to be processed
            targets (list[BoxList]): ground-truth boxes present in the image (optional)

        Returns:
            result (list[BoxList] or dict[Tensor]): the output from the model.
                During training, it returns a dict[Tensor] which contains the losses.
                During testing, it returns list[BoxList] contains additional fields
                like `scores`, `labels` and `mask` (for Mask R-CNN models).

        """
        if self.training and targets is None:
            raise ValueError("In training mode, targets should be passed")
        images = to_image_list(images)
        # start = time()
        #
        # stop = time()
        # print("backbone:"+str(stop - start) + "s")
        import torch
        if self.training :#or torch._C._get_tracing_state()
            features = self.backbone(images.tensors)
        elif self.USING_TensorRT :
            # later for tensorRT

            image = images.tensors.contiguous()
            if "level3" in self.cfg.MODEL.BACKBONE.CONV_BODY:
                features = torch.ops.maskrcnn_benchmark.FPN_level3_backbone_tensorRT_infer(image)
            else:
                features = torch.ops.maskrcnn_benchmark.FPN_level5_backbone_tensorRT_infer(image)
        else:
            features = self.backbone(images.tensors)

        if self.EXPORT_ONNX and not torch._C._get_tracing_state():
            import torch.onnx.symbolic
            # from https://github.com/NVIDIA/retinanet-examples/blob/master/retinanet/model.py#L206
            # 针对目前的tensorRT 5.0 及以下 配上pytorch1.0 1.0.1版本，必须要重载upsample_nearest2d这个操作输出。
            # Override Upsample's ONNX export until new opset is supported
            # @torch.onnx.symbolic.parse_args('v', 'is')
            # def upsample_nearest2d(g, input, output_size):
            #     height_scale = float(output_size[-2]) / input.type().sizes()[-2]
            #     width_scale = float(output_size[-1]) / input.type().sizes()[-1]
            #     return g.op("Upsample", input,
            #                 scales_f=(1, 1, height_scale, width_scale),
            #                 mode_s="nearest")
            # torch.onnx.symbolic.upsample_nearest2d = upsample_nearest2d

            # backbone transform ONNX OK
            from torch.onnx import OperatorExportTypes
            torch.onnx.export(self.backbone, images.tensors, "backbone.onnx", verbose=True, operator_export_type=OperatorExportTypes.ONNX)
            self.EXPORT_ONNX = False

        # start = time()
        proposals, proposal_losses = self.rpn(images, features, targets)
        # stop = time()
        # print("rpn:"+str(stop - start) + "s")
        if self.roi_heads:
            # start = time()
            x, result, detector_losses = self.roi_heads(features, proposals, targets)
            # stop = time()
            # print("roi_heads:" + str(stop - start) + "s")

        else:
            # RPN-only models don't have roi_heads
            x = features
            result = proposals
            detector_losses = {}

        if self.training:
            losses = {}
            losses.update(detector_losses)
            losses.update(proposal_losses)
            return losses

        return result
