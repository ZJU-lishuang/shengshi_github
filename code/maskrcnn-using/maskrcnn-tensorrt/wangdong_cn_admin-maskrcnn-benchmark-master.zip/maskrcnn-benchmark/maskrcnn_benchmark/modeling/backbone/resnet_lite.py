'''
This is a modified ResNet implementation. The original code comes from
https://github.com/pytorch/vision/edit/master/torchvision/models/resnet.py
'''

import torch
import torch.nn as nn
import torch.utils.model_zoo as model_zoo
import torchvision
from maskrcnn_benchmark.layers import FrozenBatchNorm2d
from maskrcnn_benchmark.layers import Conv2d

OutShapeArr = list()


def conv3x3(in_planes, out_planes, stride=1):
    """3x3 convolution with padding"""
    return Conv2d(in_planes, out_planes, kernel_size=3, stride=stride, padding=1, bias=False)


def conv1x1(in_planes, out_planes, stride=1):
    """1x1 convolution"""
    return Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None, frozen_bn=True):
        super(BasicBlock, self).__init__()
        self.conv1 = conv3x3(inplanes, planes, stride)
        if frozen_bn:
            self.bn1 = FrozenBatchNorm2d(planes)
        else:
            self.bn1 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes)
        if frozen_bn:
            self.bn2 = FrozenBatchNorm2d(planes)
        else:
            self.bn2 = nn.BatchNorm2d(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out

class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None, fronze_bn=True):
        super(Bottleneck, self).__init__()
        self.conv1 = conv1x1(inplanes, planes)
        if fronze_bn:
            self.bn1 = FrozenBatchNorm2d(planes)
        else:
            self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = conv3x3(planes, planes, stride)
        if fronze_bn:
            self.bn2 = FrozenBatchNorm2d(planes)
        else:
            self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = conv1x1(planes, planes * self.expansion)
        if fronze_bn:
            self.bn3 = FrozenBatchNorm2d(planes * self.expansion)
        else:
            self.bn3 = nn.BatchNorm2d(planes * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out

class ResNet(nn.Module):

    def __init__(self,cfg ,  block, layers, frozen_bn=True, zero_init_residual=False ):
        super(ResNet, self).__init__()
        self.cfg = cfg
        self.fronze_bn = frozen_bn
        self.inplanes = 64
        self.conv1 = Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
        if not frozen_bn:
            self.bn1 = nn.BatchNorm2d(64)
        else:
            self.bn1 = FrozenBatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2)
        # self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        # self.fc = nn.Linear(512 * block.expansion, num_classes)

        for m in self.modules():
            if isinstance(m, Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

        # Zero-initialize the last BN in each residual branch,
        # so that the residual branch starts with zeros, and each residual block behaves like an identity.
        # This improves the model by 0.2~0.3% according to https://arxiv.org/abs/1706.02677
        if zero_init_residual:
            for m in self.modules():
                if isinstance(m, Bottleneck):
                    nn.init.constant_(m.bn3.weight, 0)
                elif isinstance(m, BasicBlock):
                    nn.init.constant_(m.bn2.weight, 0)

    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            if not self.fronze_bn:
                downsample = nn.Sequential(
                    conv1x1(self.inplanes, planes * block.expansion, stride),
                    nn.BatchNorm2d(planes * block.expansion),
                )
            else:
                downsample = nn.Sequential(
                    conv1x1(self.inplanes, planes * block.expansion, stride),
                    FrozenBatchNorm2d(planes * block.expansion),
                )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample, frozen_bn=self.fronze_bn))
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(block(self.inplanes, planes, frozen_bn=self.fronze_bn))

        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        outputs = []

        x = self.layer1(x)
        if "level3" not in self.cfg.MODEL.BACKBONE.CONV_BODY :
            outputs.append(x)
            OutShapeArr.append(x.shape)

        x = self.layer2(x)
        outputs.append(x)
        OutShapeArr.append(x.shape)

        x = self.layer3(x)
        outputs.append(x)
        OutShapeArr.append(x.shape)

        x = self.layer4(x)
        outputs.append(x)
        OutShapeArr.append(x.shape)

        # image classification head
        # x = self.avgpool(x)
        # x = x.view(x.size(0), -1)
        # x = self.fc(x)

        return outputs

# pretrained_para_path = {
#     "resnet18": "../../pretrained_para/resnet18-5c106cde.pth",
#     "resnet34": "../../pretrained_para/resnet34-333f7ec4.pth"
# }

def resnet18(cfg , pretrained=False, pretrained_para_path=None, frozen_bn=True):
    """Constructs a ResNet-18 model.
    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
    """
    model = ResNet(cfg, BasicBlock, [2, 2, 2, 2], frozen_bn=frozen_bn)
    # if pretrained:
    #     pretrained_para = torch.load(pretrained_para_path)
    #     # filter out unnecessary parameters, and then load
    #     necessary_para = {k: v for k, v in pretrained_para.items() if k in model.state_dict()}
    #     model.load_state_dict(necessary_para)
    return model


def resnet34(cfg ,pretrained=False, pretrained_para_path=None,frozen_bn=True ):
    """Constructs a ResNet-34 model.
    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
    """
    model = ResNet(cfg ,BasicBlock, [3, 4, 6, 3], frozen_bn=frozen_bn )
    # if pretrained:
    #     pretrained_para = torch.load(pretrained_para_path)
    #     # filter out unnecessary parameters, and then load
    #     necessary_para = {k: v for k, v in pretrained_para.items() if k in model.state_dict()}
    #     model.load_state_dict(necessary_para)
    return model


if __name__ == "__main__":
    '''
    Load pretrained model (on imageNet) to visualize the feature map
    '''
    from matplotlib import pyplot as plt
    import cv2
    import numpy as np
    from random import randint
    from torchvision import transforms as T
    from maskrcnn_benchmark.structures.image_list import to_image_list
    # image preprocess
    def build_transform():
        # we are loading images with OpenCV, so we don't need to convert them
        # to BGR, they are already! So all we need to do is to normalize
        # by 255 if we want to convert to BGR255 format, or flip the channels
        # if we want it to be in RGB in [0-1] range.
        to_bgr_transform = T.Lambda(lambda x: x * 255)
        normalize_transform = T.Normalize(mean=[102.9801, 115.9465, 122.7717], std=[1., 1., 1.])

        transform = T.Compose(
            [
                T.ToPILImage(),  # this will compress to 0-1
                T.ToTensor(),
                to_bgr_transform,  # expand to 0-255
                normalize_transform,
            ]
        )
        return transform


    original_img = cv2.imread("../../testing_image/1.jpg")
    image_preprocess = build_transform()
    img = image_preprocess(original_img)
    img = to_image_list(img, size_divisible=32)

    model = resnet34(pretrained=True, pretrained_para_path=pretrained_para_path['resnet34'], frozen_bn=True)
    feature_layers = model(img.tensors)

    k = 0
    for features in feature_layers:
        k += 1
        f = features[0]
        length = f.shape[0]
        # randomly visualize three layers
        for i in range(3):
            idx = randint(0, length)
            show_f = f[idx].detach().numpy()
            show_f = show_f.astype(np.uint8)
            show_f = np.expand_dims(show_f, axis=2)
            show_f = np.concatenate((show_f, show_f, show_f), axis=2)
            plt.figure(str(k)+"_"+str(i))
            plt.imshow(show_f)
            # cv2.imshow(str(k)+"_"+str(i), show_f)
    plt.show()
    # cv2.waitKey()
    print(OutShapeArr)