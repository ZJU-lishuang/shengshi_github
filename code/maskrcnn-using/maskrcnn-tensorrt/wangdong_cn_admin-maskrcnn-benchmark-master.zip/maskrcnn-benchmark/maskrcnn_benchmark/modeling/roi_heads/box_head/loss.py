# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
import torch
from torch.nn import functional as F

from maskrcnn_benchmark.layers import smooth_l1_loss,smooth_l1_loss_with_reduction
from maskrcnn_benchmark.modeling.box_coder import BoxCoder
from maskrcnn_benchmark.modeling.matcher import Matcher
from maskrcnn_benchmark.structures.boxlist_ops import boxlist_iou
from maskrcnn_benchmark.modeling.balanced_positive_negative_sampler import (
    BalancedPositiveNegativeSampler
)
from maskrcnn_benchmark.modeling.ohem_sampler import OhemPositiveNegativeSampler
from maskrcnn_benchmark.modeling.utils import cat
import logging

class FastRCNNLossComputation(object):
    """
    Computes the loss for Faster R-CNN.
    Also supports FPN
    """

    def __init__(
        self,
        cfg,
        proposal_matcher, 
        fg_bg_sampler, 
        box_coder,
        batch_size_per_image,
        cls_agnostic_bbox_reg=False
    ):
        """
        Arguments:
            proposal_matcher (Matcher)
            fg_bg_sampler (BalancedPositiveNegativeSampler, or OhemPositiveNegativeSampler)
            box_coder (BoxCoder)
        """
        self.proposal_matcher = proposal_matcher
        self.fg_bg_sampler = fg_bg_sampler
        self.box_coder = box_coder
        self.cls_agnostic_bbox_reg = cls_agnostic_bbox_reg
        self.ohem = cfg.SOLVER.OHEM
        self.batch_size_per_image = batch_size_per_image
        # if self.ohem:
        #     self.reduction = "none"
        # else:
        self.reduction = "sum"
        self.logger = logging.getLogger("maskrcnn_benchmark.trainer")



    def match_targets_to_proposals(self, proposal, target):
        match_quality_matrix = boxlist_iou(target, proposal)
        matched_idxs = self.proposal_matcher(match_quality_matrix)
        # Fast RCNN only need "labels" field for selecting the targets
        target = target.copy_with_fields("labels")
        # get the targets corresponding GT for each proposal
        # NB: need to clamp the indices because we can have a single
        # GT in the image, and matched_idxs can be -2, which goes
        # out of bounds
        matched_targets = target[matched_idxs.clamp(min=0)]
        matched_targets.add_field("matched_idxs", matched_idxs)
        return matched_targets

    def prepare_targets(self, proposals, targets):
        labels = []
        regression_targets = []
        for proposals_per_image, targets_per_image in zip(proposals, targets):
            matched_targets = self.match_targets_to_proposals(
                proposals_per_image, targets_per_image
            )
            matched_idxs = matched_targets.get_field("matched_idxs")

            labels_per_image = matched_targets.get_field("labels")
            labels_per_image = labels_per_image.to(dtype=torch.int64)

            # Label background (below the low threshold)
            bg_inds = matched_idxs == Matcher.BELOW_LOW_THRESHOLD
            labels_per_image[bg_inds] = 0

            # Label ignore proposals (between low and high thresholds)
            ignore_inds = matched_idxs == Matcher.BETWEEN_THRESHOLDS
            labels_per_image[ignore_inds] = -1  # -1 is ignored by sampler

            # compute regression targets
            regression_targets_per_image = self.box_coder.encode(
                matched_targets.bbox, proposals_per_image.bbox
            )

            labels.append(labels_per_image)
            regression_targets.append(regression_targets_per_image)

        return labels, regression_targets

    def subsample(self, proposals, targets):
        """
        This method performs the positive/negative sampling, and return
        the sampled proposals.
        Note: this function keeps a state.

        Arguments:
            proposals (list[BoxList])
            targets (list[BoxList])
        """

        labels, regression_targets = self.prepare_targets(proposals, targets)
        sampled_pos_inds, sampled_neg_inds = self.fg_bg_sampler(labels)

        proposals = list(proposals)
        # add corresponding label and regression_targets information to the bounding boxes
        for labels_per_image, regression_targets_per_image, proposals_per_image in zip(
            labels, regression_targets, proposals
        ):
            proposals_per_image.add_field("labels", labels_per_image)
            proposals_per_image.add_field(
                "regression_targets", regression_targets_per_image
            )

        # distributed sampled proposals, that were obtained on all feature maps
        # concatenated via the fg_bg_sampler, into individual feature map levels
        self.n_proposals_per_img = []
        for img_idx, (pos_inds_img, neg_inds_img) in enumerate(
            zip(sampled_pos_inds, sampled_neg_inds)
        ):
            img_sampled_inds = torch.nonzero(pos_inds_img | neg_inds_img).squeeze(1)
            proposals_per_image = proposals[img_idx][img_sampled_inds]
            self.n_proposals_per_img.append(len(proposals_per_image))
            proposals[img_idx] = proposals_per_image

        self._proposals = proposals
        return proposals

    def mining(self, class_logits, box_regression):
        """
        Similiar role as sumsample(), but return the rois with top loss.
        Arguments:
            class_logits (list[Tensor])
            box_regression (list[Tensor])
        Returns:
            proposals (list[BoxList])
        """

        class_logits = cat(class_logits, dim=0)
        box_regression = cat(box_regression, dim=0)
        device = class_logits.device

        if not hasattr(self, "_proposals"):
            raise RuntimeError("subsample needs to be called before")

        proposals = self._proposals

        labels = cat([proposal.get_field("labels") for proposal in proposals], dim=0)
        regression_targets = cat(
            [proposal.get_field("regression_targets") for proposal in proposals], dim=0
        )

        classification_loss = F.cross_entropy(class_logits, labels, reduction='none')

        # get indices that correspond to the regression targets for
        # the corresponding ground truth labels, to be used with
        # advanced indexing
        sampled_pos_inds_subset = torch.nonzero(labels > 0).squeeze(1)
        labels_pos = labels[sampled_pos_inds_subset]
        if self.cls_agnostic_bbox_reg:
            map_inds = torch.tensor([4, 5, 6, 7], device=device)
        else:
            map_inds = 4 * labels_pos[:, None] + torch.tensor(
                [0, 1, 2, 3], device=device)

        box_loss = smooth_l1_loss_with_reduction(
            box_regression[sampled_pos_inds_subset[:, None], map_inds],
            regression_targets[sampled_pos_inds_subset],
            reduction='none',
            beta=1,
        ).sum(dim=1, keepdim=True)
        ohem_loss = classification_loss.clone()
        ohem_loss[sampled_pos_inds_subset[:, None]] = ohem_loss[sampled_pos_inds_subset[:, None]] + box_loss
        if ohem_loss.size(0) > self.batch_size_per_image:
            ohem_idx = ohem_loss.topk(self.batch_size_per_image)[1]
            lengs = [0,] + self.n_proposals_per_img
            milestones = torch.cumsum(torch.tensor(lengs,dtype = torch.int64,device = ohem_loss.device), dim=0)
            ms1 = milestones[:-1]
            ms2 = milestones[1:]
            ohem_idx = ohem_idx.sort()[0]

            # lengs = [torch.sum((el1 <= ohem_idx)*(ohem_idx < el2)) for el1, el2 in zip(ms1, ms2)]
            lengs = []
            for el1, el2 in zip(ms1, ms2):
                mid = (el1 <= ohem_idx)*(ohem_idx < el2)
                leng = torch.sum(mid)
                lengs.append(leng)
            ohem_idx = ohem_idx.split(lengs)
            ohem_idx = [el-ms1[i] for i, el in enumerate(ohem_idx)]
            self._proposals = [proposals[i][el] for i, el in enumerate(ohem_idx)]

        return self._proposals

    def __call__(self, class_logits, box_regression):
        """
        Computes the loss for Faster R-CNN.
        This requires that the subsample method has been called beforehand.

        Arguments:
            class_logits (list[Tensor])
            box_regression (list[Tensor])

        Returns:
            classification_loss (Tensor)
            box_loss (Tensor)
        """

        class_logits = cat(class_logits, dim=0)
        box_regression = cat(box_regression, dim=0)
        device = class_logits.device

        if not hasattr(self, "_proposals"):
            raise RuntimeError("subsample needs to be called before")

        proposals = self._proposals

        labels = cat([proposal.get_field("labels") for proposal in proposals], dim=0)
        regression_targets = cat(
            [proposal.get_field("regression_targets") for proposal in proposals], dim=0
        )

        # https://pytorch.org/docs/stable/_modules/torch/nn/functional.html#cross_entropy
        # default for 'F.cross_entropy'
        classification_loss = F.cross_entropy(
            class_logits, labels, reduction="mean"
        )

        # get indices that correspond to the regression targets for
        # the corresponding ground truth labels, to be used with
        # advanced indexing
        sampled_pos_inds_subset = torch.nonzero(labels > 0).squeeze(1)
        labels_pos = labels[sampled_pos_inds_subset]
        if self.cls_agnostic_bbox_reg:
            map_inds = torch.tensor([4, 5, 6, 7], device=device)
        else:
            map_inds = 4 * labels_pos[:, None] + torch.tensor(
                [0, 1, 2, 3], device=device)

        reduction = self.reduction

        box_loss = smooth_l1_loss_with_reduction(
            box_regression[sampled_pos_inds_subset[:, None], map_inds],
            regression_targets[sampled_pos_inds_subset],
            reduction=reduction,
            beta=1,
        )

        if self.reduction in ['sum',]:
            box_loss = box_loss / labels.numel()
        elif self.reduction in ['none',]:
            box_loss = box_loss.sum(dim=1)

        if self.reduction == 'none':
            num_props = classification_loss.size()[0]
            box_loss_paste = torch.zeros((num_props,), device=device)
            box_loss_paste[sampled_pos_inds_subset] = box_loss
            box_loss = box_loss_paste

        return classification_loss, box_loss

        # # get indices that correspond to the regression targets for
        # # the corresponding ground truth labels, to be used with
        # # advanced indexing
        # sampled_pos_inds_subset = torch.nonzero(labels > 0).squeeze(1)
        # labels_pos = labels[sampled_pos_inds_subset]
        # if self.cls_agnostic_bbox_reg:
        #     map_inds = torch.tensor([4, 5, 6, 7], device=device)
        # else:
        #     map_inds = 4 * labels_pos[:, None] + torch.tensor(
        #         [0, 1, 2, 3], device=device)
        #
        # box_loss = smooth_l1_loss(
        #     box_regression[sampled_pos_inds_subset[:, None], map_inds],
        #     regression_targets[sampled_pos_inds_subset],
        #     size_average=False,
        #     beta=1,
        # )
        # box_loss = box_loss / labels.numel()


        # if self.ohem:
        #
        #     classification_loss = F.cross_entropy(class_logits, labels, reduction='none')
        #     classification_n_sample = len(classification_loss)
        #     # classification_n_ohem_sample = min(self.n_ohem_sample, classification_n_sample)
        #     if self.n_ohem_sample > 1.0:
        #         self.n_ohem_sample = 1.0
        #     classification_n_ohem_sample = int(self.n_ohem_sample*classification_n_sample)
        #     # self.logger.info(("classification_n_sample:{} , classification_n_ohem_sample:{}").format
        #     #                  (classification_n_sample,
        #     #                   classification_n_ohem_sample))
        #     total_classification_loss = classification_loss.detach()
        #     _, indices = total_classification_loss.sort(descending=True)
        #     indices = indices[:classification_n_ohem_sample]
        #     final_classification_loss = torch.sum(classification_loss[indices]) / classification_n_ohem_sample
        #     return final_classification_loss, box_loss
        #
        # else:

        # classification_loss = F.cross_entropy(class_logits, labels)
        # return classification_loss, box_loss


def make_roi_box_loss_evaluator(cfg):
    matcher = Matcher(
        cfg.MODEL.ROI_HEADS.FG_IOU_THRESHOLD,
        cfg.MODEL.ROI_HEADS.BG_IOU_THRESHOLD,
        allow_low_quality_matches=False,
    )

    bbox_reg_weights = cfg.MODEL.ROI_HEADS.BBOX_REG_WEIGHTS
    box_coder = BoxCoder(weights=bbox_reg_weights)

    if cfg.SOLVER.OHEM:
        fg_bg_sampler = OhemPositiveNegativeSampler()
    else:
        fg_bg_sampler = BalancedPositiveNegativeSampler(
            cfg.MODEL.ROI_HEADS.BATCH_SIZE_PER_IMAGE,
            cfg.MODEL.ROI_HEADS.POSITIVE_FRACTION
        )

    cls_agnostic_bbox_reg = cfg.MODEL.CLS_AGNOSTIC_BBOX_REG

    loss_evaluator = FastRCNNLossComputation(
        cfg,
        matcher, 
        fg_bg_sampler, 
        box_coder, 
        cfg.MODEL.ROI_HEADS.BATCH_SIZE_PER_IMAGE,
        cls_agnostic_bbox_reg
    )

    return loss_evaluator
