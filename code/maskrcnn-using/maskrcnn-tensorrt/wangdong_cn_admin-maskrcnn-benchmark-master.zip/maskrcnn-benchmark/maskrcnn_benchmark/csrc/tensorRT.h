#pragma once
#ifdef TENSOR_RT
#include "tensorRT/vision.h"

int64_t init_backbone_tensorRT(const std::string enginePath ,const int64_t  channel, const int64_t  height , const int64_t  weight ){
    return init_backbone(enginePath,channel,height,weight);
}

std::vector<at::Tensor> FPN_level5_backbone_tensorRT_infer( at::Tensor data) {
  std::vector<at::Tensor> result = FPN_level5_backbone_infer(data);
  return result;
}

std::vector<at::Tensor> FPN_level3_backbone_tensorRT_infer( at::Tensor data) {
    std::vector<at::Tensor> result = FPN_level3_backbone_infer(data);
    return result;
}

int64_t destroy_tensorRT( const int64_t  it ){
    destroy_engine();
    return it;
}

#endif