// Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
#pragma once
#include <torch/extension.h>

int init_backbone(std::string enginePath ,int channel, int height , int weight );

std::vector<at::Tensor> FPN_level5_backbone_infer( at::Tensor data) ;

std::vector<at::Tensor> FPN_level3_backbone_infer( at::Tensor data) ;

void destroy_engine();