//
// Created by shining on 19-3-27.
//

#include <iostream>
#include <stdexcept>
#include <fstream>
#include <vector>
#include <chrono>

#include <opencv2/opencv.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <cuda_runtime.h>

#include "engine.h"
#include "vision.h"

using namespace std;
int batchSize = 1;

static  int FLAGS_Detect_size_H ;
static  int FLAGS_Detect_size_W ;
static  int FLAGS_Detect_size_C ;

TensorRT::Engine * backbone_engine = new TensorRT::Engine();

int init_backbone(std::string backbone_enginePath ,int channel, int height , int weight ){
    try {
        backbone_engine->initEngine(backbone_enginePath, /*verbose*/
                           true);
        FLAGS_Detect_size_H = height;
        FLAGS_Detect_size_W = weight;
        FLAGS_Detect_size_C = channel;
        return 0;
    }
    catch(std::exception &e) {
        std::cout << "Throw exception: " << e.what() << "\n";
        return 1;
    }

}

void destroy_engine(){
    delete backbone_engine;
}


at::Tensor prepareInputData(cv::Mat img_){
    //Mat m=Mat(rows, cols, type);
    //Mat m=Mat(Size(width,height), type);
    if(img_.channels() == 1){
        cv::cvtColor(img_,img_,cv::COLOR_GRAY2RGB);
    }

    cv::Mat img(cv::Size(FLAGS_Detect_size_W,FLAGS_Detect_size_H), CV_8UC3);
    static const float kMean[3] = {102.9801, 115.9465, 122.7717};

    cv::resize(img_, img, img.size(), 0, 0, cv::INTER_AREA);
    float * data;
    data = (float*)calloc(img.rows*img.cols * 3, sizeof(float));
    for (int c = 0; c < 3; ++c)
    {
        for (int i = 0; i < img.rows; ++i)
        { //获取第i行首像素指针
            cv::Vec3b *p1 = img.ptr<cv::Vec3b>(i);
            //cv::Vec3b *p2 = image.ptr<cv::Vec3b>(i);
            for (int j = 0; j < img.cols; ++j)
            {
                data[c * img.cols * img.rows + i * img.rows + j] = (p1[j][c]  - kMean[c]) ;
            }
        }
    }
//        img.convertTo(img, CV_32FC3);
    auto input_ = torch::tensor(at::ArrayRef<uint8_t >(img.data, img.rows * img.cols * 3)).view({img.rows, img.cols, 3});
    return input_;
}

std::vector<at::Tensor> FPN_level5_backbone_infer( at::Tensor data) {
    CHECK_INPUT(data);
    //需要【判断

    int batch = data.size(0);
    auto shape = data.sizes();
    auto input_size = backbone_engine->getInputSize();
    assert(data.size(2) != input_size[0]);
    assert(data.size(3) != input_size[1]);


    auto outputs = backbone_engine->getOutputSize(1);
    auto result_FPN320 = at::zeros({batch, outputs[0][0], outputs[0][1], outputs[0][2]}, data.options());
    auto result_FPN324 = at::zeros({batch, outputs[1][0], outputs[1][1], outputs[1][2]}, data.options());
    auto result_FPN328 = at::zeros({batch, outputs[2][0], outputs[2][1], outputs[2][2]}, data.options());
    auto result_FPN332 = at::zeros({batch, outputs[3][0], outputs[3][1], outputs[3][2]}, data.options());
    auto result_FPN333 = at::zeros({batch, outputs[4][0], outputs[4][1], outputs[4][2]}, data.options());
    // create GPU buffers and a stream   创建GPU缓冲区和流
    // 输出：return (%332, %328, %324, %320, %333);
    // %332 : Float(1, 64, 120, 160)
    // %328 : Float(1, 64, 60, 80)
    // %324 : Float(1, 64, 30, 40)
    // %320 : Float(1, 64, 15, 20)
    // %333 : Float(1, 64, 8, 10)
    // TensorRT out
//    binding: x.1
//    size: 921600
//    dtype: <class 'numpy.float32'>
//    binding: 320
//    size: 19200
//    dtype: <class 'numpy.float32'>
//                  binding: 324
//    size: 76800
//    dtype: <class 'numpy.float32'>
//                  binding: 328
//    size: 307200
//    dtype: <class 'numpy.float32'>
//                  binding: 332
//    size: 1228800
//    dtype: <class 'numpy.float32'>
//                  binding: 333
//    size: 5120
//    dtype: <class 'numpy.float32'>
    vector<void *> buffers;
    for (auto buffer : {data, result_FPN320, result_FPN324, result_FPN328 , result_FPN332 ,result_FPN333}) {
        buffers.push_back(buffer.data<float>());
    }

    backbone_engine->infer(buffers, batch);

    return {result_FPN332, result_FPN328, result_FPN324 , result_FPN320 ,result_FPN333};
}

std::vector<at::Tensor> FPN_level3_backbone_infer( at::Tensor data) {
    CHECK_INPUT(data);
    //需要【判断

    int batch = data.size(0);
    auto shape = data.sizes();
    auto input_size = backbone_engine->getInputSize();
    assert(data.size(2) != input_size[0]);
    assert(data.size(3) != input_size[1]);


    auto outputs = backbone_engine->getOutputSize(1);
    auto result_FPN316 = at::zeros({batch, outputs[0][0], outputs[0][1], outputs[0][2]}, data.options());
    auto result_FPN320 = at::zeros({batch, outputs[1][0], outputs[1][1], outputs[1][2]}, data.options());
    auto result_FPN324 = at::zeros({batch, outputs[2][0], outputs[2][1], outputs[2][2]}, data.options());
    // create GPU buffers and a stream   创建GPU缓冲区和流
    // 输出： return (%324, %320, %316);
    // %332 : Float(1, 64, 120, 160)
    // %328 : Float(1, 64, 60, 80)
    // %324 : Float(1, 64, 30, 40)
    // %320 : Float(1, 64, 15, 20)
    // %333 : Float(1, 64, 8, 10)
    // TensorRT out
//    binding: x.1
//    size: 921600
//    dtype: <class 'numpy.float32'>
//                  binding: 316
//    size: 19200
//    dtype: <class 'numpy.float32'>
//                  binding: 320
//    size: 76800
//    dtype: <class 'numpy.float32'>
//                  binding: 324
//    size: 307200
//    dtype: <class 'numpy.float32'>
    vector<void *> buffers;
    for (auto buffer : {data, result_FPN316, result_FPN320, result_FPN324}) {
        buffers.push_back(buffer.data<float>());
    }

    backbone_engine->infer(buffers, batch);

    return {result_FPN324, result_FPN320, result_FPN316 };
}


int main_test(int argc, char *argv[]) {
//	if (argc != 3) {
//		cerr << "Usage: " << argv[0] << " backbone_engine.plan image.jpg" << endl;
//		return 1;
//	}

    cout << "Loading backbone_engine..." << endl;
    int ret = init_backbone("/home/shining/Projects/work/maskrcnn-xray/tensorRT/backbone.trt" ,3 , 480 , 640);

    cout << "Preparing data..." << endl;
    auto image = imread("/home/shining/Projects/datasets/Following/Trailing_test_data/2018_07_17_hxxy_1/2018-07-12_video_8272.jpg", cv::IMREAD_COLOR);
    at::Tensor data =prepareInputData(image);
    data = data.unsqueeze(0);
    data = data.to(torch::kFloat32);
    data = data.to(torch::kCUDA);

    // Run inference n times
    cout << "Running inference..." << endl;
    const int count = 100;
    auto start = chrono::steady_clock::now();
    try {
        for (int i = 0; i < count; i++) {
            std::vector<at::Tensor> results = FPN_level5_backbone_infer(data);
        }
    }
    catch(std::exception &e) {
        std::cout << "Throw exception: " << e.what() << "\n";
    }

    auto stop = chrono::steady_clock::now();
    auto timing = chrono::duration_cast<chrono::duration<double>>(stop - start);
    cout << "Took " << timing.count() / count << " seconds per inference." << endl;

    destroy_engine();
//	// Write image
//	imwrite("detections.png", image);

    return 0;
}
