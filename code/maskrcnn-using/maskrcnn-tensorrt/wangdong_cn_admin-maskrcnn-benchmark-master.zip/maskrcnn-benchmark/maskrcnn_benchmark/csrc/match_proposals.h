#pragma once
#include "cuda/vision.h"
#ifndef _match_proposals_h_
#define _match_proposals_h_ 


at::Tensor match_proposals( at::Tensor match_quality_matrix,
                            const int64_t allow_low_quality_matches,
                            double low_th,
                            double high_th){
  bool allow = false ;
  if(allow_low_quality_matches > 0){
    allow = true;
  }
  at::Tensor result = match_proposals_cuda( match_quality_matrix, allow, low_th, high_th);
  return result;
}

 #endif