import os

import torch


torch.ops.load_library(os.path.join(os.path.dirname(__file__), 'lib', 'custom_ops.cpython-36m-x86_64-linux-gnu.so'))
#torch.ops.load_library('/home/shining/Projects/work/maskrcnn-pytorch/maskrcnn_benchmark/csrc/custom_ops/build/libmaskrcnn_benchmark_customops.so')