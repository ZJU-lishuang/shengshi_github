# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
# from ._utils import _C
# from maskrcnn_benchmark import _C
#
# soft_nms = _C.soft_nms
import torch

init_backbone_tensorRT = torch.ops.maskrcnn_benchmark.init_backbone_tensorRT
FPN_level5_backbone_tensorRT_infer = torch.ops.maskrcnn_benchmark.FPN_level5_backbone_tensorRT_infer
FPN_level3_backbone_tensorRT_infer = torch.ops.maskrcnn_benchmark.FPN_level3_backbone_tensorRT_infer
destroy_tensorRT = torch.ops.maskrcnn_benchmark.destroy_tensorRT
# soft_nms.__doc__ = """
# This function performs Soft Non-maximum suppresion (https://arxiv.org/abs/1704.04503)"""
