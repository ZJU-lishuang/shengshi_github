# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
import torch

# we need this for the custom ops to exist
import maskrcnn_benchmark._custom_ops   # noqa: F401

box_encode = torch.ops.maskrcnn_benchmark.box_encode

# nms.__doc__ = """
# This function performs Non-maximum suppresion"""
