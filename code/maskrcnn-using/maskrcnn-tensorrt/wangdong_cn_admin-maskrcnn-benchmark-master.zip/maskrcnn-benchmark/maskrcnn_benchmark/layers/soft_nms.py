# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
# from ._utils import _C
# from maskrcnn_benchmark import _C
#
# soft_nms = _C.soft_nms
import torch
soft_nms = torch.ops.maskrcnn_benchmark.soft_nms
# soft_nms.__doc__ = """
# This function performs Soft Non-maximum suppresion (https://arxiv.org/abs/1704.04503)"""
