# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
import torch

# we need this for the custom ops to exist
import maskrcnn_benchmark._custom_ops   # noqa: F401

generate_mask_targets = None # = torch.ops.maskrcnn_benchmark.generate_mask_targets

# nms.__doc__ = """
# This function performs Non-maximum suppresion"""
