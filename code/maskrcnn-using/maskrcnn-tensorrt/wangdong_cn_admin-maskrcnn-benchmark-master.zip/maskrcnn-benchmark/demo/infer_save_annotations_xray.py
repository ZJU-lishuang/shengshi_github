import matplotlib.pyplot as plt

from PIL import Image
import os
import shutil
import json
from io import BytesIO
import cv2
import numpy as np
import argparse
# this makes our figures bigger
from time import time

import torch
from maskrcnn_benchmark.config import cfg
from predictor_Xray import XrayDetector

IMG_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.ppm', '.bmp', '.pgm']
def is_image_file(filename):
    """Checks if a file is an image.
      Args:
          filename (string): path to a file
      Returns:
          bool: True if the filename ends with a known image extension
    """
    filename_lower = filename.lower()
    return any(filename_lower.endswith(ext) for ext in IMG_EXTENSIONS)


def get_imagelist_from_dir(dirpath):
    images = []
    for f in os.listdir(dirpath):
        if is_image_file(f):
            images.append(os.path.join(dirpath, f))
    return images


path_name = "/home/shining/Projects/datasets/Xray/images/train/20180511"
# path_name = "/home/shining/Projects/datasets/Following/Trailing_test_data/2018_07_12_1_company_1"


def parse_args():
    """Parse in command line arguments"""
    parser = argparse.ArgumentParser(description='Demonstrate mask-rcnn results')
    parser.add_argument(
        '--image_dir',
        dest='image_dir',
        default= path_name ,
       # default='/home/shining/Projects/datasets/Train_data_new/child_cmopany_2018_07_14/JPEGImages',
        help='directory to load images for demo'
    )
    parser.add_argument(
        '--images', nargs='+',
        #default=["/home/shining/Projects/datasets/Following/Trailing_test_data/2018_07_17_hxxy_1/2018-07-12_video_8272.jpg"],
        help='images to infer. Must not use with --image_dir')
    parser.add_argument(
        '--output_dir',
        help='directory to save demo results',
        default=path_name + "/vis_outputs")
        #default="/home/shining/Projects/datasets/Train_data_new/child_cmopany_2018_07_14/vis_outputs_company_50du_2018_11_29")
    parser.add_argument(
        '--is_save_json',
        help='whether to save demo json results', type=bool,
        default=True)
    parser.add_argument(
        '--output_json_dir',
        help='directory to save demo json results',
        default=path_name + "/vis_outputs/json_results")
        #default="/home/shining/Projects/datasets/Train_data_new/child_cmopany_2018_07_14/vis_outputs_company_50du_2018_11_29/json_results")
    return  parser.parse_args()

args = parse_args()
print('Called with args:')
print(args)

isExists = os.path.exists(args.output_dir)
if not isExists:
    os.mkdir(args.output_dir)
else:
    shutil.rmtree(args.output_dir)

## output json formate 输出mask_anotation 能识别并显示的文件
isExists = os.path.exists(args.output_json_dir)
if args.is_save_json == True:
    if not isExists:
        os.makedirs(args.output_json_dir)
    # else:
    #     shutil.rmtree(args.output_json_dir)
    #     os.rmdir(args.output_json_dir)




# config_file = "../configs/caffe2/e2e_mask_rcnn_R_50_FPN_1x_caffe2.yaml"
config_file = "/home/shining/work/maskrcnn-shining/configs/My/Xray_e2e_mask_rcnn_R_50_FPN_1x_inference.yaml"
# config_file = "/home/shining/Projects/work/maskrcnn-xray/configs/My/Following_faster_rcnn_R_50_v1d_37_FPN_level3_1x.yaml"



# update the config options with the config file
cfg.merge_from_file(config_file)
# manual override some options
cfg.merge_from_list(["MODEL.DEVICE", "cuda"])

detector = XrayDetector(
    cfg,
    confidence_threshold=0.9,
    show_mask_heatmaps=False,
    masks_per_dim=2,
    size=(800,960),#(h,w)(288,384)(480,640)
    save_json = args.is_save_json
)

if cfg.TEST.USING_TensorRT:
    enginePath = "/home/shining/Projects/work/maskrcnn-xray/tensorRT/backbone.trt"
    channel = 3
    height = 480
    weight = 640
    torch.ops.maskrcnn_benchmark.init_backbone_tensorRT(enginePath , channel ,height ,weight)

if args.image_dir:
    imglist = get_imagelist_from_dir(args.image_dir)
else:
    imglist = args.images
num_images = len(imglist)
if not os.path.exists(args.output_dir + "/none/"):
    os.makedirs(args.output_dir + "/none/")
if not os.path.exists(args.output_dir + "/single/"):
    os.makedirs(args.output_dir + "/single/")
if not os.path.exists(args.output_dir + "/double/"):
    os.makedirs(args.output_dir + "/double/")
if not os.path.exists(args.output_dir + "/three/"):
    os.makedirs(args.output_dir + "/three/")

for i in range(num_images):
    print('img:', imglist[i])


    # # from http://cocodataset.org/#explore?id=345434
   # pil_image = Image.open(imglist[i]).convert("RGB")
    # if cfg.DATALOADER.SIZE_DIVISIBILITY:
    #     assert (image.size(0) % cfg.DATALOADER.SIZE_DIVISIBILITY == 0
    #             and image.size(1) % cfg.DATALOADER.SIZE_DIVISIBILITY == 0)
    # convert to BGR format
   # image = np.array(pil_image)[:, :, [2, 1, 0]]
    image=cv2.imread(imglist[i])
    #
    # compute predictions

    start = time()
    predictions,dict_list ,boxnum = detector.run_on_opencv_image(image)
    # save result images
    stop = time()
    print(str(stop-start) + "s")

    if boxnum == 0:
        output_name = "none/" +os.path.basename(imglist[i]).strip('.jpg') + '.' + "jpg"
        output_name = os.path.join(args.output_dir, '{}'.format(output_name))
        cv2.imwrite(output_name, predictions)
    elif boxnum == 1:
        output_name ="single/" + os.path.basename(imglist[i]).strip('.jpg') + '.' + "jpg"
        output_name = os.path.join(args.output_dir, '{}'.format(output_name))
        cv2.imwrite(output_name, predictions)

    elif boxnum == 2:
        output_name ="double/" + os.path.basename(imglist[i]).strip('.jpg') + '.' + "jpg"
        output_name = os.path.join(args.output_dir, '{}'.format(output_name))
        cv2.imwrite(output_name, predictions)
    else:
        output_name = "three/" + os.path.basename(imglist[i]).strip('.jpg') + '.' + "jpg"
        output_name = os.path.join(args.output_dir, '{}'.format(output_name))
        cv2.imwrite(output_name, predictions)
    if args.is_save_json:


        output_namej = os.path.basename(imglist[i]).strip('.jpg') + '.json'

        jsPath = os.path.join(args.output_json_dir, '{}'.format(output_namej))
        djson = {"filename": os.path.basename(imglist[i]),
                 "imgHeight": image.shape[0],
                 "imgWidth": image.shape[1],
                 "objects": dict_list
                 }

        with open(jsPath, "w") as f:
            json.dump(djson, f, sort_keys=True, indent=4)
        print("%s saved." % jsPath)
if cfg.TEST.USING_TensorRT:
    torch.ops.maskrcnn_benchmark.destroy_tensorRT(0)