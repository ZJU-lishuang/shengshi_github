# Using Jit and not using Jit compare 
import torch

from PIL import Image
from time import time
import numpy
import cv2
import os
import argparse,shutil

torch.ops.load_library("/home/shining/Projects/work/maskrcnn-xray/maskrcnn_benchmark/lib/custom_ops.cpython-36m-x86_64-linux-gnu.so")

CATEGORIES = [
    '__background__', 'person',
]
confidence_threshold = 0.9
# Use torch.jit.trace to generate a torch.jit.ScriptModule via tracing.
traced_script_module = torch.jit.load("/home/shining/Projects/work/maskrcnn-xray/trace/model_single_image_to_top_predictions.pt",map_location=torch.device('cuda:0'))#
print(traced_script_module.graph)
# traced_script_module.eval()
device = torch.device('cpu' if torch.cuda.is_available() else 'cuda:0')
#device = torch.device('cpu')
traced_script_module.cuda()


IMG_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.ppm', '.bmp', '.pgm']
def is_image_file(filename):
    """Checks if a file is an image.
      Args:
          filename (string): path to a file
      Returns:
          bool: True if the filename ends with a known image extension
    """
    filename_lower = filename.lower()
    return any(filename_lower.endswith(ext) for ext in IMG_EXTENSIONS)


def get_imagelist_from_dir(dirpath):
    images = []
    for f in os.listdir(dirpath):
        if is_image_file(f):
            images.append(os.path.join(dirpath, f))
    return images

path_name = "/home/shining/Projects/datasets/Following/Trailing_test_data/nannning_xianchang_1"

def parse_args():
    """Parse in command line arguments"""
    parser = argparse.ArgumentParser(description='Demonstrate mask-rcnn results')
    parser.add_argument(
        '--image_dir',
        dest='image_dir',
        default=path_name,
        help='directory to load images for demo'
    )
    parser.add_argument(
        '--images', nargs='+',
        # default=["/home/shining/Projects/datasets/Following/Trailing_test_data/2018_06_06_1_company_2/vis_outputs_company_50du_2018_11_29/single/image_50zhen_2018_11_29_613.jpg"]
        help='images to infer. Must not use with --image_dir')
    parser.add_argument(
        '--output_dir',
        help='directory to save demo results',
        default=path_name+"/vis_outputs")
    parser.add_argument(
        '--is_save_json',
        help='whether to save demo json results', type=bool,
        default=True)
    parser.add_argument(
        '--output_json_dir',
        help='directory to save demo json results',
        default=path_name+"/vis_outputs/json_results")
    return  parser.parse_args()

args = parse_args()
print('Called with args:')
print(args)

isExists = os.path.exists(args.output_dir)
if not isExists:
    os.mkdir(args.output_dir)

## output json formate 输出mask_anotation 能识别并显示的文件
isExists = os.path.exists(args.output_json_dir)
if args.is_save_json == True:
    if not isExists:
        os.mkdir(args.output_json_dir)
    else:
        shutil.rmtree(args.output_json_dir)
        os.mkdir(args.output_json_dir)

def overlay_class_names(image, scores,labels ,boxes):


    labels = [CATEGORIES[i] for i in labels]


    template = "{}: {:.2f}"
    for box, score, label in zip(boxes, scores, labels):
        x, y = box[:2]
        s = template.format(label, score)
        cv2.putText(
            image, s, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2
        )
    return image

def overlay_annotations( image, labels, boxes, ratio_w, ratio_h):
    for box, idx in zip(boxes, labels):
        y1 = box[1] /ratio_h;
        x1 = box[0] /ratio_w;
        y2 = box[3] /ratio_h;
        x2 = box[2] /ratio_w;
        x1 = x1.to(torch.int64)
        y1 = y1.to(torch.int64)
        x2 = x2.to(torch.int64)
        y2 = y2.to(torch.int64)
        top_left = (x1,y1)
        bottom_right = (x2,y2)

        image = cv2.rectangle(
            image, tuple(top_left), tuple(bottom_right), (0, 0, 255), 8
        )

    return image

#Size(width  ,height)
def prepareInputData(img_,size = (640,480)):
    ratio_h = size[1] / float(img_.shape[0]);

    ratio_w = size[0] / float(img_.shape[1]);
    if(img_.ndim == 2):
        cv2.cvtColor(img_,img_,cv2.COLOR_GRAY2RGB)

    img_= cv2.resize(img_,size)
    image = torch.from_numpy(numpy.array(img_)[:, :, [0, 1, 2]])
    image = image.float()

    return image, ratio_w, ratio_h






if args.image_dir:
    imglist = get_imagelist_from_dir(args.image_dir)
else:
    imglist = args.images
num_images = len(imglist)
if not os.path.exists(args.output_dir + "/nonesingle/"):
    os.makedirs(args.output_dir + "/nonesingle/")
if not os.path.exists(args.output_dir + "/single/"):
    os.makedirs(args.output_dir + "/single/")


for i in range(num_images):
    print('img:', imglist[i])

    image = cv2.imread(imglist[i])
    # convert to BGR format
    original_image = image
    image, ratio_w, ratio_h = prepareInputData(image)

    start = time()
    # output = traced_script_module(image)
    scores,boxes, labels  = traced_script_module(image.to(device))# ,boxes, labels, masks
    keep = (scores >= confidence_threshold)
    scores = scores[keep]
    boxes = boxes[keep]
    labels = labels[keep]
    stop = time()
    print(str(stop-start) + "s")
#    masks = masks[keep]
    #result = traced_script_module(image.to(device))
    result_image = overlay_annotations(original_image, labels.cpu(), boxes.cpu(), ratio_w, ratio_h)
    result = overlay_class_names(result_image, scores,labels,boxes )
    if boxes.size(0) != 1:
        output_name = "nonesingle/" +os.path.basename(imglist[i]).strip('.jpg') + '.' + "jpg"
        output_name = os.path.join(args.output_dir, '{}'.format(output_name))
        cv2.imwrite(output_name, result)
    else:
        output_name ="single/" + os.path.basename(imglist[i]).strip('.jpg') + '.' + "jpg"
        output_name = os.path.join(args.output_dir, '{}'.format(output_name))
        cv2.imwrite(output_name, result)