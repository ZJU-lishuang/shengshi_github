# Installing Prerequisites
1. Make sure you have the python dependencies installed.
    - For python2, run `python2 -m pip install -r requirements.txt` from the root directory of this sample.
    - For python3, run `python3 -m pip install -r requirements.txt` from the root directory of this sample.

# 截止到目前的tegra nano ｔｅｎｓｏｒｒｔ５．０．２．６１,只能运行ｐｙｔｈｏｎ２版本的

#使用步骤：
pre 1. 必须使用demo中的代码先生成特定模块的onnx模型，如backbone.onnx。 
1. 使用 backbone_onnx_to_tensorrt.py将生成的onnx模型转为tensorrt的序列化模型。当然序列化的方法有很多，这里只是其中一种，还有https://github.com/onnx/onnx-tensorrt 中生成的onnx2trt可执行程序，也可以实现。
还有tensorrt包中提供的trtexec可执行程序。
2. 特别注意，序列化是针对特定的硬件的，嵌入式的TX2，nano 必须在设备上进行序列化，PC上序列化的无法使用。



# 注意
Tensorrt 5.0的python API目前只支持python3.5 版本
# Tensorrt开发流程
1. 先通过python 的tensorrt API将我们的onnx的网络输入和输出size和type确定。注意打印信息：
```bash
binding: x.1
size: 921600
dtype: <class 'numpy.float32'>
binding: 320
size: 19200
dtype: <class 'numpy.float32'>
binding: 324
size: 76800
dtype: <class 'numpy.float32'>
binding: 328
size: 307200
dtype: <class 'numpy.float32'>
binding: 332
size: 1228800
dtype: <class 'numpy.float32'>
binding: 333
size: 5120
dtype: <class 'numpy.float32'>
```
然后匹配onnx的导出图，构建完整的C++内存分配。
```yaml
graph(%x.1 : Float(1, 3, 480, 640)
      %1 : Float(64, 3, 7, 7)
      %2 : Float(64)
      %3 : Float(64)
      %4 : Float(64)
      %5 : Float(64)
      %6 : Float(64, 64, 3, 3)
      %7 : Float(64)
      %8 : Float(64)
      %9 : Float(64)
      %10 : Float(64)
      %11 : Float(64, 64, 3, 3)
      %12 : Float(64)
      %13 : Float(64)
      %14 : Float(64)
      %15 : Float(64)
      %16 : Float(64, 64, 3, 3)
      %17 : Float(64)
      %18 : Float(64)
      %19 : Float(64)
      %20 : Float(64)
      %21 : Float(64, 64, 3, 3)
      %22 : Float(64)
      %23 : Float(64)
      %24 : Float(64)
      %25 : Float(64)
      %26 : Float(64, 64, 3, 3)
      %27 : Float(64)
      %28 : Float(64)
      %29 : Float(64)
      %30 : Float(64)
      %31 : Float(64, 64, 3, 3)
      %32 : Float(64)
      %33 : Float(64)
      %34 : Float(64)
      %35 : Float(64)
      %36 : Float(128, 64, 3, 3)
      %37 : Float(128)
      %38 : Float(128)
      %39 : Float(128)
      %40 : Float(128)
      %41 : Float(128, 128, 3, 3)
      %42 : Float(128)
      %43 : Float(128)
      %44 : Float(128)
      %45 : Float(128)
      %46 : Float(128, 64, 1, 1)
      %47 : Float(128)
      %48 : Float(128)
      %49 : Float(128)
      %50 : Float(128)
      %51 : Float(128, 128, 3, 3)
      %52 : Float(128)
      %53 : Float(128)
      %54 : Float(128)
      %55 : Float(128)
      %56 : Float(128, 128, 3, 3)
      %57 : Float(128)
      %58 : Float(128)
      %59 : Float(128)
      %60 : Float(128)
      %61 : Float(128, 128, 3, 3)
      %62 : Float(128)
      %63 : Float(128)
      %64 : Float(128)
      %65 : Float(128)
      %66 : Float(128, 128, 3, 3)
      %67 : Float(128)
      %68 : Float(128)
      %69 : Float(128)
      %70 : Float(128)
      %71 : Float(128, 128, 3, 3)
      %72 : Float(128)
      %73 : Float(128)
      %74 : Float(128)
      %75 : Float(128)
      %76 : Float(128, 128, 3, 3)
      %77 : Float(128)
      %78 : Float(128)
      %79 : Float(128)
      %80 : Float(128)
      %81 : Float(256, 128, 3, 3)
      %82 : Float(256)
      %83 : Float(256)
      %84 : Float(256)
      %85 : Float(256)
      %86 : Float(256, 256, 3, 3)
      %87 : Float(256)
      %88 : Float(256)
      %89 : Float(256)
      %90 : Float(256)
      %91 : Float(256, 128, 1, 1)
      %92 : Float(256)
      %93 : Float(256)
      %94 : Float(256)
      %95 : Float(256)
      %96 : Float(256, 256, 3, 3)
      %97 : Float(256)
      %98 : Float(256)
      %99 : Float(256)
      %100 : Float(256)
      %101 : Float(256, 256, 3, 3)
      %102 : Float(256)
      %103 : Float(256)
      %104 : Float(256)
      %105 : Float(256)
      %106 : Float(256, 256, 3, 3)
      %107 : Float(256)
      %108 : Float(256)
      %109 : Float(256)
      %110 : Float(256)
      %111 : Float(256, 256, 3, 3)
      %112 : Float(256)
      %113 : Float(256)
      %114 : Float(256)
      %115 : Float(256)
      %116 : Float(256, 256, 3, 3)
      %117 : Float(256)
      %118 : Float(256)
      %119 : Float(256)
      %120 : Float(256)
      %121 : Float(256, 256, 3, 3)
      %122 : Float(256)
      %123 : Float(256)
      %124 : Float(256)
      %125 : Float(256)
      %126 : Float(256, 256, 3, 3)
      %127 : Float(256)
      %128 : Float(256)
      %129 : Float(256)
      %130 : Float(256)
      %131 : Float(256, 256, 3, 3)
      %132 : Float(256)
      %133 : Float(256)
      %134 : Float(256)
      %135 : Float(256)
      %136 : Float(256, 256, 3, 3)
      %137 : Float(256)
      %138 : Float(256)
      %139 : Float(256)
      %140 : Float(256)
      %141 : Float(256, 256, 3, 3)
      %142 : Float(256)
      %143 : Float(256)
      %144 : Float(256)
      %145 : Float(256)
      %146 : Float(512, 256, 3, 3)
      %147 : Float(512)
      %148 : Float(512)
      %149 : Float(512)
      %150 : Float(512)
      %151 : Float(512, 512, 3, 3)
      %152 : Float(512)
      %153 : Float(512)
      %154 : Float(512)
      %155 : Float(512)
      %156 : Float(512, 256, 1, 1)
      %157 : Float(512)
      %158 : Float(512)
      %159 : Float(512)
      %160 : Float(512)
      %161 : Float(512, 512, 3, 3)
      %162 : Float(512)
      %163 : Float(512)
      %164 : Float(512)
      %165 : Float(512)
      %166 : Float(512, 512, 3, 3)
      %167 : Float(512)
      %168 : Float(512)
      %169 : Float(512)
      %170 : Float(512)
      %171 : Float(512, 512, 3, 3)
      %172 : Float(512)
      %173 : Float(512)
      %174 : Float(512)
      %175 : Float(512)
      %176 : Float(512, 512, 3, 3)
      %177 : Float(512)
      %178 : Float(512)
      %179 : Float(512)
      %180 : Float(512)
      %181 : Float(64, 64, 1, 1)
      %182 : Float(64)
      %183 : Float(64, 64, 3, 3)
      %184 : Float(64)
      %185 : Float(64, 128, 1, 1)
      %186 : Float(64)
      %187 : Float(64, 64, 3, 3)
      %188 : Float(64)
      %189 : Float(64, 256, 1, 1)
      %190 : Float(64)
      %191 : Float(64, 64, 3, 3)
      %192 : Float(64)
      %193 : Float(64, 512, 1, 1)
      %194 : Float(64)
      %195 : Float(64, 64, 3, 3)
      %196 : Float(64)) {
  %197 : Float(1, 64, 240, 320) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[7, 7], pads=[3, 3, 3, 3], strides=[2, 2]](%x.1, %1), scope: Sequential/ResNet[body]/Conv2d[conv1]
  %198 : Float(1, 64, 240, 320) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%197, %2, %3, %4, %5), scope: Sequential/ResNet[body]/FrozenBatchNorm2d[bn1]
  %199 : Float(1, 64, 240, 320) = onnx::Relu(%198), scope: Sequential/ResNet[body]/ReLU[relu]
  %200 : Float(1, 64, 120, 160) = onnx::MaxPool[kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[2, 2]](%199), scope: Sequential/ResNet[body]/MaxPool2d[maxpool]
  %201 : Float(1, 64, 120, 160) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%200, %6), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[0]/Conv2d[conv1]
  %202 : Float(1, 64, 120, 160) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%201, %7, %8, %9, %10), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[0]/FrozenBatchNorm2d[bn1]
  %203 : Float(1, 64, 120, 160) = onnx::Relu(%202), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[0]/ReLU[relu]
  %204 : Float(1, 64, 120, 160) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%203, %11), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[0]/Conv2d[conv2]
  %205 : Float(1, 64, 120, 160) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%204, %12, %13, %14, %15), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[0]/FrozenBatchNorm2d[bn2]
  %206 : Float(1, 64, 120, 160) = onnx::Add(%205, %200), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[0]
  %207 : Float(1, 64, 120, 160) = onnx::Relu(%206), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[0]/ReLU[relu]
  %208 : Float(1, 64, 120, 160) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%207, %16), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[1]/Conv2d[conv1]
  %209 : Float(1, 64, 120, 160) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%208, %17, %18, %19, %20), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[1]/FrozenBatchNorm2d[bn1]
  %210 : Float(1, 64, 120, 160) = onnx::Relu(%209), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[1]/ReLU[relu]
  %211 : Float(1, 64, 120, 160) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%210, %21), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[1]/Conv2d[conv2]
  %212 : Float(1, 64, 120, 160) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%211, %22, %23, %24, %25), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[1]/FrozenBatchNorm2d[bn2]
  %213 : Float(1, 64, 120, 160) = onnx::Add(%212, %207), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[1]
  %214 : Float(1, 64, 120, 160) = onnx::Relu(%213), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[1]/ReLU[relu]
  %215 : Float(1, 64, 120, 160) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%214, %26), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[2]/Conv2d[conv1]
  %216 : Float(1, 64, 120, 160) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%215, %27, %28, %29, %30), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[2]/FrozenBatchNorm2d[bn1]
  %217 : Float(1, 64, 120, 160) = onnx::Relu(%216), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[2]/ReLU[relu]
  %218 : Float(1, 64, 120, 160) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%217, %31), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[2]/Conv2d[conv2]
  %219 : Float(1, 64, 120, 160) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%218, %32, %33, %34, %35), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[2]/FrozenBatchNorm2d[bn2]
  %220 : Float(1, 64, 120, 160) = onnx::Add(%219, %214), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[2]
  %221 : Float(1, 64, 120, 160) = onnx::Relu(%220), scope: Sequential/ResNet[body]/Sequential[layer1]/BasicBlock[2]/ReLU[relu]
  %222 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[2, 2]](%221, %36), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]/Conv2d[conv1]
  %223 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%222, %37, %38, %39, %40), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]/FrozenBatchNorm2d[bn1]
  %224 : Float(1, 128, 60, 80) = onnx::Relu(%223), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]/ReLU[relu]
  %225 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%224, %41), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]/Conv2d[conv2]
  %226 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%225, %42, %43, %44, %45), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]/FrozenBatchNorm2d[bn2]
  %227 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[1, 1], pads=[0, 0, 0, 0], strides=[2, 2]](%221, %46), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]/Sequential[downsample]/Conv2d[0]
  %228 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%227, %47, %48, %49, %50), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]/Sequential[downsample]/FrozenBatchNorm2d[1]
  %229 : Float(1, 128, 60, 80) = onnx::Add(%226, %228), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]
  %230 : Float(1, 128, 60, 80) = onnx::Relu(%229), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[0]/ReLU[relu]
  %231 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%230, %51), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[1]/Conv2d[conv1]
  %232 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%231, %52, %53, %54, %55), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[1]/FrozenBatchNorm2d[bn1]
  %233 : Float(1, 128, 60, 80) = onnx::Relu(%232), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[1]/ReLU[relu]
  %234 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%233, %56), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[1]/Conv2d[conv2]
  %235 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%234, %57, %58, %59, %60), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[1]/FrozenBatchNorm2d[bn2]
  %236 : Float(1, 128, 60, 80) = onnx::Add(%235, %230), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[1]
  %237 : Float(1, 128, 60, 80) = onnx::Relu(%236), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[1]/ReLU[relu]
  %238 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%237, %61), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[2]/Conv2d[conv1]
  %239 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%238, %62, %63, %64, %65), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[2]/FrozenBatchNorm2d[bn1]
  %240 : Float(1, 128, 60, 80) = onnx::Relu(%239), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[2]/ReLU[relu]
  %241 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%240, %66), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[2]/Conv2d[conv2]
  %242 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%241, %67, %68, %69, %70), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[2]/FrozenBatchNorm2d[bn2]
  %243 : Float(1, 128, 60, 80) = onnx::Add(%242, %237), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[2]
  %244 : Float(1, 128, 60, 80) = onnx::Relu(%243), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[2]/ReLU[relu]
  %245 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%244, %71), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[3]/Conv2d[conv1]
  %246 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%245, %72, %73, %74, %75), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[3]/FrozenBatchNorm2d[bn1]
  %247 : Float(1, 128, 60, 80) = onnx::Relu(%246), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[3]/ReLU[relu]
  %248 : Float(1, 128, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%247, %76), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[3]/Conv2d[conv2]
  %249 : Float(1, 128, 60, 80) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%248, %77, %78, %79, %80), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[3]/FrozenBatchNorm2d[bn2]
  %250 : Float(1, 128, 60, 80) = onnx::Add(%249, %244), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[3]
  %251 : Float(1, 128, 60, 80) = onnx::Relu(%250), scope: Sequential/ResNet[body]/Sequential[layer2]/BasicBlock[3]/ReLU[relu]
  %252 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[2, 2]](%251, %81), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]/Conv2d[conv1]
  %253 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%252, %82, %83, %84, %85), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]/FrozenBatchNorm2d[bn1]
  %254 : Float(1, 256, 30, 40) = onnx::Relu(%253), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]/ReLU[relu]
  %255 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%254, %86), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]/Conv2d[conv2]
  %256 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%255, %87, %88, %89, %90), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]/FrozenBatchNorm2d[bn2]
  %257 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[1, 1], pads=[0, 0, 0, 0], strides=[2, 2]](%251, %91), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]/Sequential[downsample]/Conv2d[0]
  %258 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%257, %92, %93, %94, %95), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]/Sequential[downsample]/FrozenBatchNorm2d[1]
  %259 : Float(1, 256, 30, 40) = onnx::Add(%256, %258), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]
  %260 : Float(1, 256, 30, 40) = onnx::Relu(%259), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[0]/ReLU[relu]
  %261 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%260, %96), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[1]/Conv2d[conv1]
  %262 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%261, %97, %98, %99, %100), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[1]/FrozenBatchNorm2d[bn1]
  %263 : Float(1, 256, 30, 40) = onnx::Relu(%262), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[1]/ReLU[relu]
  %264 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%263, %101), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[1]/Conv2d[conv2]
  %265 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%264, %102, %103, %104, %105), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[1]/FrozenBatchNorm2d[bn2]
  %266 : Float(1, 256, 30, 40) = onnx::Add(%265, %260), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[1]
  %267 : Float(1, 256, 30, 40) = onnx::Relu(%266), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[1]/ReLU[relu]
  %268 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%267, %106), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[2]/Conv2d[conv1]
  %269 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%268, %107, %108, %109, %110), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[2]/FrozenBatchNorm2d[bn1]
  %270 : Float(1, 256, 30, 40) = onnx::Relu(%269), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[2]/ReLU[relu]
  %271 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%270, %111), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[2]/Conv2d[conv2]
  %272 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%271, %112, %113, %114, %115), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[2]/FrozenBatchNorm2d[bn2]
  %273 : Float(1, 256, 30, 40) = onnx::Add(%272, %267), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[2]
  %274 : Float(1, 256, 30, 40) = onnx::Relu(%273), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[2]/ReLU[relu]
  %275 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%274, %116), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[3]/Conv2d[conv1]
  %276 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%275, %117, %118, %119, %120), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[3]/FrozenBatchNorm2d[bn1]
  %277 : Float(1, 256, 30, 40) = onnx::Relu(%276), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[3]/ReLU[relu]
  %278 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%277, %121), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[3]/Conv2d[conv2]
  %279 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%278, %122, %123, %124, %125), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[3]/FrozenBatchNorm2d[bn2]
  %280 : Float(1, 256, 30, 40) = onnx::Add(%279, %274), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[3]
  %281 : Float(1, 256, 30, 40) = onnx::Relu(%280), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[3]/ReLU[relu]
  %282 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%281, %126), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[4]/Conv2d[conv1]
  %283 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%282, %127, %128, %129, %130), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[4]/FrozenBatchNorm2d[bn1]
  %284 : Float(1, 256, 30, 40) = onnx::Relu(%283), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[4]/ReLU[relu]
  %285 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%284, %131), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[4]/Conv2d[conv2]
  %286 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%285, %132, %133, %134, %135), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[4]/FrozenBatchNorm2d[bn2]
  %287 : Float(1, 256, 30, 40) = onnx::Add(%286, %281), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[4]
  %288 : Float(1, 256, 30, 40) = onnx::Relu(%287), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[4]/ReLU[relu]
  %289 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%288, %136), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[5]/Conv2d[conv1]
  %290 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%289, %137, %138, %139, %140), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[5]/FrozenBatchNorm2d[bn1]
  %291 : Float(1, 256, 30, 40) = onnx::Relu(%290), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[5]/ReLU[relu]
  %292 : Float(1, 256, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%291, %141), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[5]/Conv2d[conv2]
  %293 : Float(1, 256, 30, 40) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%292, %142, %143, %144, %145), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[5]/FrozenBatchNorm2d[bn2]
  %294 : Float(1, 256, 30, 40) = onnx::Add(%293, %288), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[5]
  %295 : Float(1, 256, 30, 40) = onnx::Relu(%294), scope: Sequential/ResNet[body]/Sequential[layer3]/BasicBlock[5]/ReLU[relu]
  %296 : Float(1, 512, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[2, 2]](%295, %146), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]/Conv2d[conv1]
  %297 : Float(1, 512, 15, 20) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%296, %147, %148, %149, %150), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]/FrozenBatchNorm2d[bn1]
  %298 : Float(1, 512, 15, 20) = onnx::Relu(%297), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]/ReLU[relu]
  %299 : Float(1, 512, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%298, %151), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]/Conv2d[conv2]
  %300 : Float(1, 512, 15, 20) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%299, %152, %153, %154, %155), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]/FrozenBatchNorm2d[bn2]
  %301 : Float(1, 512, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[1, 1], pads=[0, 0, 0, 0], strides=[2, 2]](%295, %156), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]/Sequential[downsample]/Conv2d[0]
  %302 : Float(1, 512, 15, 20) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%301, %157, %158, %159, %160), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]/Sequential[downsample]/FrozenBatchNorm2d[1]
  %303 : Float(1, 512, 15, 20) = onnx::Add(%300, %302), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]
  %304 : Float(1, 512, 15, 20) = onnx::Relu(%303), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[0]/ReLU[relu]
  %305 : Float(1, 512, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%304, %161), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[1]/Conv2d[conv1]
  %306 : Float(1, 512, 15, 20) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%305, %162, %163, %164, %165), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[1]/FrozenBatchNorm2d[bn1]
  %307 : Float(1, 512, 15, 20) = onnx::Relu(%306), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[1]/ReLU[relu]
  %308 : Float(1, 512, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%307, %166), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[1]/Conv2d[conv2]
  %309 : Float(1, 512, 15, 20) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%308, %167, %168, %169, %170), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[1]/FrozenBatchNorm2d[bn2]
  %310 : Float(1, 512, 15, 20) = onnx::Add(%309, %304), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[1]
  %311 : Float(1, 512, 15, 20) = onnx::Relu(%310), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[1]/ReLU[relu]
  %312 : Float(1, 512, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%311, %171), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[2]/Conv2d[conv1]
  %313 : Float(1, 512, 15, 20) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%312, %172, %173, %174, %175), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[2]/FrozenBatchNorm2d[bn1]
  %314 : Float(1, 512, 15, 20) = onnx::Relu(%313), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[2]/ReLU[relu]
  %315 : Float(1, 512, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%314, %176), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[2]/Conv2d[conv2]
  %316 : Float(1, 512, 15, 20) = onnx::BatchNormalization[epsilon=1e-05, momentum=0.9](%315, %177, %178, %179, %180), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[2]/FrozenBatchNorm2d[bn2]
  %317 : Float(1, 512, 15, 20) = onnx::Add(%316, %311), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[2]
  %318 : Float(1, 512, 15, 20) = onnx::Relu(%317), scope: Sequential/ResNet[body]/Sequential[layer4]/BasicBlock[2]/ReLU[relu]
  %319 : Float(1, 64, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[1, 1], pads=[0, 0, 0, 0], strides=[1, 1]](%318, %193, %194), scope: Sequential/FPN[fpn]/Conv2d[fpn_inner4]
  %320 : Float(1, 64, 15, 20) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%319, %195, %196), scope: Sequential/FPN[fpn]/Conv2d[fpn_layer4]
  %321 : Float(1, 64, 30, 40) = onnx::Upsample[mode="nearest", scales=[1, 1, 2, 2]](%319), scope: Sequential/FPN[fpn]
  %322 : Float(1, 64, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[1, 1], pads=[0, 0, 0, 0], strides=[1, 1]](%295, %189, %190), scope: Sequential/FPN[fpn]/Conv2d[fpn_inner3]
  %323 : Float(1, 64, 30, 40) = onnx::Add(%322, %321), scope: Sequential/FPN[fpn]
  %324 : Float(1, 64, 30, 40) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%323, %191, %192), scope: Sequential/FPN[fpn]/Conv2d[fpn_layer3]
  %325 : Float(1, 64, 60, 80) = onnx::Upsample[mode="nearest", scales=[1, 1, 2, 2]](%323), scope: Sequential/FPN[fpn]
  %326 : Float(1, 64, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[1, 1], pads=[0, 0, 0, 0], strides=[1, 1]](%251, %185, %186), scope: Sequential/FPN[fpn]/Conv2d[fpn_inner2]
  %327 : Float(1, 64, 60, 80) = onnx::Add(%326, %325), scope: Sequential/FPN[fpn]
  %328 : Float(1, 64, 60, 80) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%327, %187, %188), scope: Sequential/FPN[fpn]/Conv2d[fpn_layer2]
  %329 : Float(1, 64, 120, 160) = onnx::Upsample[mode="nearest", scales=[1, 1, 2, 2]](%327), scope: Sequential/FPN[fpn]
  %330 : Float(1, 64, 120, 160) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[1, 1], pads=[0, 0, 0, 0], strides=[1, 1]](%221, %181, %182), scope: Sequential/FPN[fpn]/Conv2d[fpn_inner1]
  %331 : Float(1, 64, 120, 160) = onnx::Add(%330, %329), scope: Sequential/FPN[fpn]
  %332 : Float(1, 64, 120, 160) = onnx::Conv[dilations=[1, 1], group=1, kernel_shape=[3, 3], pads=[1, 1, 1, 1], strides=[1, 1]](%331, %183, %184), scope: Sequential/FPN[fpn]/Conv2d[fpn_layer1]
  %333 : Float(1, 64, 8, 10) = onnx::MaxPool[kernel_shape=[1, 1], pads=[0, 0, 0, 0], strides=[2, 2]](%320), scope: Sequential/FPN[fpn]/LastLevelMaxPool[top_blocks]
  return (%332, %328, %324, %320, %333);
}
```