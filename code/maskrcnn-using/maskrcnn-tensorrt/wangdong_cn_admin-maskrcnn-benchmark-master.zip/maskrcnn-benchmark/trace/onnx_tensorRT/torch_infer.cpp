//
// Created by shining on 19-3-27.
//

#include <iostream>
#include <stdexcept>
#include <fstream>
#include <vector>
#include <chrono>

#include <opencv2/opencv.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <cuda_runtime.h>

#include "engine.h"
#include <ATen/cuda/CUDAContext.h>
#include "torch/script.h"

using namespace std;
int batchSize = 1;

static  int FLAGS_Detect_size_H ;
static  int FLAGS_Detect_size_W ;
static  int FLAGS_Detect_size_C ;

TensorRT::Engine * engine = new TensorRT::Engine();

int init_engine(std::string enginePath ,int channel, int height , int weight ){
    try {
        engine->initEngine(enginePath, /*verbose*/
                           true);
        FLAGS_Detect_size_H = height;
        FLAGS_Detect_size_W = weight;
        FLAGS_Detect_size_C = channel;
        return 0;
    }
    catch(std::exception &e) {
        std::cout << "Throw exception: " << e.what() << "\n";
        return 1;
    }

}

void destroy_engine(){
    delete engine;
}


at::Tensor prepareInputData(cv::Mat img_){
    //Mat m=Mat(rows, cols, type);
    //Mat m=Mat(Size(width,height), type);
    if(img_.channels() == 1){
        cv::cvtColor(img_,img_,cv::COLOR_GRAY2RGB);
    }

    cv::Mat img(cv::Size(FLAGS_Detect_size_W,FLAGS_Detect_size_H), CV_8UC3);
    static const float kMean[3] = {102.9801, 115.9465, 122.7717};

    cv::resize(img_, img, img.size(), 0, 0, cv::INTER_AREA);
    float * data;
    data = (float*)calloc(img.rows*img.cols * 3, sizeof(float));
    for (int c = 0; c < 3; ++c)
    {
        for (int i = 0; i < img.rows; ++i)
        { //获取第i行首像素指针
            cv::Vec3b *p1 = img.ptr<cv::Vec3b>(i);
            //cv::Vec3b *p2 = image.ptr<cv::Vec3b>(i);
            for (int j = 0; j < img.cols; ++j)
            {
                data[c * img.cols * img.rows + i * img.rows + j] = (p1[j][c]  - kMean[c]) ;
            }
        }
    }
//        img.convertTo(img, CV_32FC3);
    auto input_ = torch::tensor(at::ArrayRef<uint8_t >(img.data, img.rows * img.cols * 3)).view({img.rows, img.cols, 3});
    return input_;
}

std::vector<at::Tensor> backbone_infer( at::Tensor data) {
    CHECK_INPUT(data);
    //需要【判断

    int batch = data.size(0);
    auto shape = data.sizes();
    auto input_size = engine->getInputSize();
    assert(data.size(2) != input_size[0]);
    assert(data.size(3) != input_size[1]);


    auto outputs = engine->getOutputSize(1);
    auto result_FPN320 = at::zeros({batch, outputs[0][0], outputs[0][1], outputs[0][2]}, data.options());
    auto result_FPN324 = at::zeros({batch, outputs[1][0], outputs[1][1], outputs[1][2]}, data.options());
    auto result_FPN328 = at::zeros({batch, outputs[2][0], outputs[2][1], outputs[2][2]}, data.options());
//    auto result_FPN332 = at::zeros({batch, outputs[3][0], outputs[3][1], outputs[3][2]}, data.options());
//    auto result_FPN333 = at::zeros({batch, outputs[4][0], outputs[4][1], outputs[4][2]}, data.options());

    vector<void *> buffers;
    for (auto buffer : {data, result_FPN320, result_FPN324, result_FPN328 }) {//, result_FPN332 ,result_FPN333
        buffers.push_back(buffer.data<float>());
    }

    engine->infer(buffers, batch);

    return {result_FPN320, result_FPN324, result_FPN328 };//, result_FPN332 ,result_FPN333};
}

int main(int argc, char *argv[]) {
//	if (argc != 3) {
//		cerr << "Usage: " << argv[0] << " engine.plan image.jpg" << endl;
//		return 1;
//	}

    cout << "Loading engine..." << endl;
    int ret = init_engine("/home/nano/work/maskrcnn-benchmark/tensorRT/backbone.trt" ,3 , 480 , 640);

    cout << "Preparing data..." << endl;
    auto image = imread("/home/nano/work/maskrcnn-benchmark/2017-05-05-11-58-54_src6882.jpg", cv::IMREAD_COLOR);
    at::Tensor data =prepareInputData(image);
    data = data.unsqueeze(0);
    data = data.to(torch::kFloat32);
    data = data.to(torch::kCUDA);

    // Run inference n times
    cout << "Running inference..." << endl;
    const int count = 100;
    auto start = chrono::steady_clock::now();
    try {
        for (int i = 0; i < count; i++) {
            std::vector<at::Tensor> results = backbone_infer(data);
        }
    }
    catch(std::exception &e) {
        std::cout << "Throw exception: " << e.what() << "\n";
    }

    auto stop = chrono::steady_clock::now();
    auto timing = chrono::duration_cast<chrono::duration<double>>(stop - start);
    cout << "Took " << timing.count() / count << " seconds per inference." << endl;

    destroy_engine();
//	// Write image
//	imwrite("detections.png", image);

    return 0;
}
