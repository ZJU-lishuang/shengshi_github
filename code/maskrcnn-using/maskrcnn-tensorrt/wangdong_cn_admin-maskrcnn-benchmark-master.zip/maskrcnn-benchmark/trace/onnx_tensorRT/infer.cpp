#include <iostream>
#include <stdexcept>
#include <fstream>
#include <vector>
#include <chrono>

#include <opencv2/opencv.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <cuda_runtime.h>

#include "engine.h"
#include <ATen/cuda/CUDAContext.h>
#include "torch/script.h"

using namespace std;
int batchSize = 1;



vector<at::Tensor> infer(TensorRT::Engine &engine, at::Tensor data) {
    CHECK_INPUT(data);

    int batch = data.size(0);
    auto input_size = engine.getInputSize();
    data = at::constant_pad_nd(data, {0, input_size[1] - data.size(3), 0, input_size[0] - data.size(2)});

    int num_detections = engine.getMaxDetections();
    auto scores = at::zeros({batch, num_detections}, data.options());
    auto boxes = at::zeros({batch, num_detections, 4}, data.options());
    auto classes = at::zeros({batch, num_detections}, data.options());

    vector<void *> buffers;
    for (auto buffer : {data, scores, boxes, classes}) {
        buffers.push_back(buffer.data<float>());
    }

    engine.infer(buffers, batch);

    return {scores, boxes, classes};
}

int main(int argc, char *argv[]) {
//	if (argc != 3) {
//		cerr << "Usage: " << argv[0] << " engine.plan image.jpg" << endl;
//		return 1;
//	}

	cout << "Loading engine..." << endl;
	auto engine = TensorRT::Engine("/home/nano/work/maskrcnn-benchmark/tensorRT/backbone.trt", /*verbose*/
                                   true);

	cout << "Preparing data..." << endl;
	auto image = imread("/home/nano/work/maskrcnn-benchmark/2017-05-05-11-58-54_src6882.jpg", cv::IMREAD_COLOR);
	auto inputSize = engine.getInputSize();
	cv::resize(image, image, cv::Size(inputSize[0], inputSize[1]));
        cv::Mat pixels;
        image.convertTo(pixels, CV_32FC3, 1.0 /*/ 255*/, 0);

        int channels = 3;
        vector<float> img;
        vector<float> data (channels * inputSize[0] * inputSize[1]);

        if (pixels.isContinuous())
            img.assign((float*)pixels.datastart, (float*)pixels.dataend);
        else {
            cerr << "Error reading image " << argv[2] << endl;
            return -1;
        }

        vector<float> mean {102.9801, 115.9465, 122.7717};
        vector<float> std {0.229, 0.224, 0.225};
  
        for (int c = 0; c < channels; c++) {
            for (int j = 0, hw = inputSize[0] * inputSize[1]; j < hw; j++) {
                data[c * hw + j] = (img[channels * j + 2 - c] - mean[c]);
            }
        }        

	// Create device buffers
	//注意，千万不要用vector<void *> buffers，去给里面的选项分配cudaMalloc ,会直接段错误。
	void *data_d, *FPN320, *FPN324, *FPN328 ,*FPN332 ,*FPN333;
	auto num_det = engine.getMaxDetections();
    auto outputs = engine.getOutputSize(1);
    //, FPN324, FPN328 ,FPN332 ,FPN333
    TENSORRTCHECK(cudaMalloc(&data_d,batchSize * 3 * inputSize[0] * inputSize[1] * sizeof(float)));
    TENSORRTCHECK(cudaMalloc(&FPN320, batchSize * outputs[0][0]*outputs[0][1]*outputs[0][2] * sizeof(float)));
    TENSORRTCHECK(cudaMalloc(&FPN324, batchSize * outputs[1][0]*outputs[1][1]*outputs[1][2] * sizeof(float)));
    TENSORRTCHECK(cudaMalloc(&FPN328, batchSize * outputs[2][0]*outputs[2][1]*outputs[2][2] * sizeof(float)));
//    TENSORRTCHECK(cudaMalloc(&FPN332, batchSize * outputs[3][0]*outputs[3][1]*outputs[3][2] * sizeof(float)));
//    TENSORRTCHECK(cudaMalloc(&FPN333, batchSize * outputs[4][0]*outputs[4][1]*outputs[4][2] * sizeof(float)));
//    for (int b = 0; b < engine._engine->getNbBindings(); ++b) {
//
//		const char *name_ = engine._engine->getBindingName(b);
//		if (engine._engine->bindingIsInput(b)){
//			TENSORRTCHECK(cudaMalloc(&data_d,batchSize * 3 * inputSize[0] * inputSize[1] * sizeof(float)));
//
//		}
//		else{
//
//			TENSORRTCHECK(cudaMalloc(&FPN320, batchSize * outputs[b-1][0]*outputs[b-1][1]*outputs[b-1][2] * sizeof(float)));
//		}
//	}


    vector<void *> buffers = { data_d, FPN320 ,FPN324 ,FPN328 };//,FPN332 ,FPN333

	// Copy image to device
	size_t dataSize = data.size() * sizeof(float);
	cudaMemcpy(data_d, data.data(), dataSize, cudaMemcpyHostToDevice);

	// Run inference n times
	cout << "Running inference..." << endl;
	const int count = 100;
	auto start = chrono::steady_clock::now();
    try {
        for (int i = 0; i < count; i++) {
            engine.infer(buffers, 1);
        }
    }
    catch(std::exception &e) {
        std::cout << "Throw exception: " << e.what() << "\n";
    }

	auto stop = chrono::steady_clock::now();
	auto timing = chrono::duration_cast<chrono::duration<double>>(stop - start);
	cout << "Took " << timing.count() / count << " seconds per inference." << endl;

	// Get back the bounding boxes
	auto result_FPN320 = new float[batchSize * outputs[0][0]*outputs[0][1]*outputs[0][2]];
    auto result_FPN324 = new float[batchSize * outputs[1][0]*outputs[1][1]*outputs[1][2]];
    auto result_FPN328 = new float[batchSize * outputs[2][0]*outputs[2][1]*outputs[2][2]];
//    auto result_FPN332 = new float[batchSize * outputs[3][0]*outputs[3][1]*outputs[3][2]];
//    auto result_FPN333 = new float[batchSize * outputs[4][0]*outputs[4][1]*outputs[4][2]];



	TENSORRTCHECK(cudaMemcpy(result_FPN320, FPN320, sizeof(float) * batchSize * outputs[0][0]*outputs[0][1]*outputs[0][2], cudaMemcpyDeviceToHost));
    TENSORRTCHECK(cudaMemcpy(result_FPN324, FPN324, sizeof(float) * batchSize * outputs[1][0]*outputs[1][1]*outputs[1][2], cudaMemcpyDeviceToHost));
    TENSORRTCHECK(cudaMemcpy(result_FPN328, FPN328, sizeof(float) * batchSize * outputs[2][0]*outputs[2][1]*outputs[2][2], cudaMemcpyDeviceToHost));
//    TENSORRTCHECK(cudaMemcpy(result_FPN332, FPN332, sizeof(float) * batchSize * outputs[3][0]*outputs[3][1]*outputs[3][2], cudaMemcpyDeviceToHost));
//    TENSORRTCHECK(cudaMemcpy(result_FPN333, FPN333, sizeof(float) * batchSize * outputs[4][0]*outputs[4][1]*outputs[4][2], cudaMemcpyDeviceToHost));

//
//	for (int i = 0; i < num_det; i++) {
//		// Show results over confidence threshold
//		if (scores[i] >= 0.3f) {
//			float x1 = boxes[i*4+0];
//			float y1 = boxes[i*4+1];
//			float x2 = boxes[i*4+2];
//			float y2 = boxes[i*4+3];
//			cout << "Found box {" << x1 << ", " << y1 << ", " << x2 << ", " << y2
//				<< "} with score " << scores[i] << " and class " << classes[i] << endl;
//
//			// Draw bounding box on image
//			cv::rectangle(image, cv::Point(x1, y1), cv::Point(x2, y2), cv::Scalar(0, 255, 0));
//		}
//	}
//
	delete[] result_FPN320, result_FPN324, result_FPN328;//, result_FPN332 ,result_FPN333;
//
//	// Write image
//	imwrite("detections.png", image);

	return 0;
}
