#include <iostream>
#include <stdexcept>
#include <fstream>
#include <vector>

#include "engine.h"

using namespace std;

// Sample program to build a TensorRT Engine from an ONNX model from RetinaNet
//
// By default TensorRT will target FP16 precision (supported on Pascal, Volta, and Turing GPUs)
//
// You can optionally provide an INT8CalibrationTable file created during RetinaNet INT8 calibration
// to build a TensorRT engine with INT8 precision

int main(int argc, char *argv[]) {
	if (argc != 3 && argc != 4) {
		cerr << "Usage: " << argv[0] << " core_model.onnx engine.plan {Int8CalibrationTable}" << endl;
		return 1;
	}

	ifstream onnxFile;
	onnxFile.open(argv[1], ios::in | ios::binary); 

        if (!onnxFile.good()) {
            cerr << "\nERROR: Unable to read specified ONNX model " << argv[1] << endl;
            return -1;
        }

	onnxFile.seekg (0, onnxFile.end);
	size_t size = onnxFile.tellg();
	onnxFile.seekg (0, onnxFile.beg);

	auto *buffer = new char[size];
	onnxFile.read(buffer, size);
	onnxFile.close();

        // Define default RetinaNet parameters to use for TRT export
	int batch = 1;
        size_t workspace_size =(1ULL << 30);
        bool verbose = false;


        // For now, assume we have already done calibration elsewhere 
        // if we want to create an INT8 TensorRT engine, so no need 
        // to provide calibration files or model name
        const vector<string> calibration_files;
        string model_name = "";
        string calibration_table = argc == 4 ? string(argv[3]) : "";

        // Use FP16 precision by default, use INT8 if calibration table is provided
        string precision = "FP16";
        if (argc == 4)
            precision = "INT8";

	cout << "Building engine..." << endl;
	auto engine = TensorRT::Engine(buffer, size, batch, precision, calibration_files, model_name, calibration_table, verbose, workspace_size);
	engine.save(string(argv[2]));


	delete [] buffer;

	return 0;
}
