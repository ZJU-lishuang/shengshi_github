/*
 * Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#pragma once

#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <NvInfer.h>

#include <cuda_runtime.h>

using namespace std;

static int gUseDLACore{ -1 };

// 如果使用CHECK，会跟pytorch中的源码冲突
#define TENSORRTCHECK(status)                     \
    do                                            \
    {                                             \
        auto ret = (status);                      \
        if (ret != 0)                             \
        {                                         \
            std::cout << "Cuda failure: " << ret; \
            abort();                              \
        }                                         \
    } while (0)

#define CHECK_CUDA(x) AT_ASSERTM(x.type().is_cuda(), #x " must be a CUDA tensor")
#define CHECK_CONTIGUOUS(x) AT_ASSERTM(x.is_contiguous(), #x " must be contiguous")
#define CHECK_INPUT(x) CHECK_CUDA(x); CHECK_CONTIGUOUS(x)

namespace TensorRT {

inline void enableDLA(nvinfer1::IBuilder* b, int useDLACore)
{
    if (useDLACore >= 0)
    {
        b->allowGPUFallback(true);
        b->setFp16Mode(true);
        b->setDefaultDeviceType(nvinfer1::DeviceType::kDLA);
        b->setDLACore(useDLACore);
    }
}


    // RetinaNet wrapper around TensorRT CUDA engine
class Engine {
public:
    nvinfer1::ICudaEngine *_engine = nullptr;

    Engine();

    // Create engine from engine path
    Engine(const string &engine_path, bool verbose=false);

    // Create engine from engine path
    void initEngine(const string &engine_path, bool verbose=false);

    // Create engine from serialized onnx model
    Engine(const char *onnx_model, size_t onnx_size, size_t batch, string precision,
           const vector<string>& calibration_images,
           string model_name, string calibration_table, bool verbose, size_t workspace_size=(1ULL << 30));

    ~Engine();

    // Save model to path
    void save(const string &path);

    // Infer using pre-allocated GPU buffers {data, scores, boxes, classes}
    void infer(vector<void *> &buffers, int batch=1);

    // one Input Get (h, w) size of the fixed input
    vector<int> getInputSize();

    // 获取Input 的所有 Size
    vector<vector<int>>  getInputSize(int inputNum);

    // 获取Output 的所有 Size
    vector<vector<int>> getOutputSize( int inputNum );

    // Get max allowed batch size
    int getMaxBatchSize();

    // Get max number of detections
    int getMaxDetections();

    // Get stride
    int getStride();

private:
    nvinfer1::IRuntime *_runtime = nullptr;
    nvinfer1::IExecutionContext *_context = nullptr;
    cudaStream_t _stream = nullptr;

    void _load(const string &path);
    void _prepare();

};

}
