/*
 * Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "engine.h"

#include <iostream>
#include <fstream>

#include <NvOnnxConfig.h>
#include <NvOnnxParser.h>


#include "calibrator.h"

using namespace nvinfer1;
using namespace nvonnxparser;

namespace TensorRT {

class Logger : public ILogger {
public:
    Logger(bool verbose)
        : _verbose(verbose) {
    }

    void log(Severity severity, const char *msg) override {
        if (_verbose || (severity != Severity::kINFO))
            cout << msg << endl;
    }

private:
   bool _verbose{false};
};

void Engine::_load(const string &path) {
    ifstream file(path, ios::in | ios::binary);
    file.seekg (0, file.end);
    size_t size = file.tellg();
    file.seekg (0, file.beg);

    char *buffer = new char[size];
    file.read(buffer, size);
    file.close();

    _engine = _runtime->deserializeCudaEngine(buffer, size, nullptr);

    delete[] buffer;
}

void Engine::_prepare() {
    _context = _engine->createExecutionContext();
    cudaStreamCreate(&_stream);
}

Engine::Engine() {
}

Engine::Engine(const string &path, bool verbose) {
    Logger logger(verbose);
    _runtime = createInferRuntime(logger);
    _load(path);
    _prepare();
}

void Engine::initEngine(const string &path, bool verbose) {
    Logger logger(verbose);
    _runtime = createInferRuntime(logger);
    _load(path);
    _prepare();
}


Engine::~Engine() {
    if (_stream) cudaStreamDestroy(_stream);
    if (_context) _context->destroy();
    if (_engine) _engine->destroy();
    if (_runtime) _runtime->destroy();
}


void Engine::save(const string &path) {
    cout << "Writing to " << path << "..." << endl;
    auto serialized = _engine->serialize();
    ofstream file(path, ios::out | ios::binary);
    file.write(reinterpret_cast<const char*>(serialized->data()), serialized->size());

    serialized->destroy();    
}

void Engine::infer(vector<void *> &buffers, int batch) {
    _context->enqueue(batch, buffers.data(), _stream, nullptr);
//    _context->execute(batch, buffers.data());
    cudaStreamSynchronize(_stream);

}

Engine::Engine(const char *onnx_model, size_t onnx_size, size_t batch, string precision,
                 const vector<string>& calibration_images,
               string model_name, string calibration_table, bool verbose, size_t workspace_size) {

    Logger logger(verbose);
    _runtime = createInferRuntime(logger);
    if (gUseDLACore >= 0)
    {
        _runtime->setDLACore(gUseDLACore);
    }
    bool fp16 = precision.compare("FP16") == 0;
    bool int8 = precision.compare("INT8") == 0;

    // Create builder
    auto builder = createInferBuilder(logger);
    builder->setMaxBatchSize(batch);
    // Allow use of FP16 layers when running in INT8
    builder->setFp16Mode(fp16 || int8);
    builder->setMaxWorkspaceSize(workspace_size);

    // Parse ONNX FCN
    cout << "Building " << precision << " core model..." << endl;
    auto network = builder->createNetwork();
    auto parser = createParser(*network, logger);
    parser->parse(onnx_model, onnx_size);

    auto input = network->getInput(0);
    auto inputDims = input->getDimensions();

    if (int8) {
        if ( !builder->platformHasFastInt8()){
            return ;
        }
        builder->setInt8Mode(int8);
        ImageStream stream(batch, inputDims, calibration_images);
        Int8EntropyCalibrator* calib = new Int8EntropyCalibrator(stream, model_name, calibration_table);
        builder->setInt8Calibrator(calib);
    }
    enableDLA(builder, gUseDLACore);

    // Build engine
    cout << "Applying optimizations and building TRT CUDA engine..." << endl;
    _engine = builder->buildCudaEngine(*network);

    // Housekeeping
    parser->destroy();
    network->destroy();
    builder->destroy();

    _prepare();
}

vector<vector<int>>  Engine::getInputSize(int inputNum) {

    vector<vector<int>> shapes;
    for (int i = 0; i < inputNum; ++i) {
        auto dims = _engine->getBindingDimensions(i);
        vector<int> shape{dims.d[0], dims.d[1],dims.d[2], dims.d[3]};
        shapes.push_back(shape);
    }

    return shapes;
}
vector<int> Engine::getInputSize() {
    auto dims = _engine->getBindingDimensions(0);
    return {dims.d[1], dims.d[2]};
}

vector<vector<int>> Engine::getOutputSize( int inputNum ) {
    vector<vector<int>> shapes;
    for (int b = inputNum; b < _engine->getNbBindings(); ++b) {

        const char *name_ = _engine->getBindingName(b);
        auto dims = _engine->getBindingDimensions(_engine->getBindingIndex(name_));
        vector<int> shape{dims.d[0], dims.d[1],dims.d[2]};
        shapes.push_back(shape);
    }
    return shapes;
}

int Engine::getMaxBatchSize() {
    return _engine->getMaxBatchSize();
}

int Engine::getMaxDetections() {
    return _engine->getBindingDimensions(1).d[0];
}

int Engine::getStride() {
    return 1;
}

}
