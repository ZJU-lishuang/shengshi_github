# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
import numpy
from matplotlib import pyplot

import torch

from PIL import Image
from maskrcnn_benchmark.config import cfg
from predictor_Xray import XrayDetector
from maskrcnn_benchmark.structures.image_list import ImageList,to_image_list
import cv2
import copy
#if __name__ == "__main__":
# load config from file and command-line arguments
cfg.merge_from_file("../configs/My/Xray_e2e_mask_rcnn_R_50_v1d_48_FPN_1x.yaml")
cfg.merge_from_list(["MODEL.DEVICE", "cuda"])
cfg.freeze()
image_size=(800,960)#576,416; 800,960
device = torch.device("cuda")
# prepare object that handles inference plus adds predictions on top of image
coco_demo = XrayDetector(
    cfg,
    confidence_threshold=0.7,
    show_mask_heatmaps=False,
    masks_per_dim=2,
    min_image_size=480,
)

if cfg.TEST.USING_TensorRT:
    enginePath = "/home/shining/work/maskrcnn-shining/trace/Xray/backbone.trt"
    channel = 3
    height = image_size[1]
    weight = image_size[0]
    torch.ops.maskrcnn_benchmark.init_backbone_tensorRT(enginePath , channel ,height ,weight)

def single_image_to_top_predictions(image):
    image = image.to(device)
    image = image.permute(0, 3, 1, 2)
    # # we are loading images with OpenCV, so we don't need to convert them
    # # to BGR, they are already! So all we need to do is to normalize
    # # by 255 if we want to convert to BGR255 format, or flip the channels
    # # if we want it to be in RGB in [0-1] range.
    # if not cfg.INPUT.TO_BGR255:
    #     image = image / 255.0
    #     image = image[[0, 3, 2, 1]]
    #else:
        # image = image * 255

    # we absolutely want fixed size (int) here (or we run into a tracing error (or bug?)
    # or we might later decide to make things work with variable size...
    mean = torch.tensor(cfg.INPUT.PIXEL_MEAN, device=device)[None,:, None, None]
    image = image- mean
    # should also do variance...

    #image=image.to(torch.device("cuda"))
    # image_list = ImageList(image, [(int(image.size(-2)), int(image.size(-1)))])
    image_list = to_image_list(image)
    image_list = image_list.to(device)
    result = coco_demo.model(image_list)
    # reshape prediction (a BoxList) into the original image size
    results = []
    for item in result:
        scores = item.get_field("scores")
        results.append(scores)
        results.append(item.bbox)
        results.append(item.get_field("labels"))

    # keep = (scores >= coco_demo.confidence_threshold)
    # result = (scores[keep],
    #           result.bbox[keep],
    #           result.get_field("labels")[keep],
    #           result.get_field("mask")[keep],
    #           )
    return tuple(results)


@torch.jit.script
def my_paste_mask(mask, bbox, height: int, width: int, threshold: float=0.5, padding: int=1, contour: bool=True, rectangle: bool=False):
    padded_mask = torch.constant_pad_nd(mask, (padding, padding, padding, padding))
    scale = 1.0 + 2.0 * float(padding) / float(mask.size(-1))
    center_x = (bbox[2] + bbox[0]) * 0.5
    center_y = (bbox[3] + bbox[1]) * 0.5
    w_2 = (bbox[2] - bbox[0]) * 0.5 * scale
    h_2 = (bbox[3] - bbox[1]) * 0.5 * scale  # should have two scales?
    bbox_scaled = torch.stack([center_x - w_2, center_y - h_2,
                               center_x + w_2, center_y + h_2], 0)

    TO_REMOVE = 1
    w = (bbox_scaled[2] - bbox_scaled[0] + TO_REMOVE).clamp(min=1).long()
    h = (bbox_scaled[3] - bbox_scaled[1] + TO_REMOVE).clamp(min=1).long()

    scaled_mask = torch.ops.maskrcnn_benchmark.upsample_bilinear(padded_mask.float(), h, w)

    x0 = bbox_scaled[0].long()
    y0 = bbox_scaled[1].long()
    x = x0.clamp(min=0)
    y = y0.clamp(min=0)
    leftcrop = x - x0
    topcrop = y - y0
    w = torch.min(w - leftcrop, width - x)
    h = torch.min(h - topcrop, height - y)

    # mask = torch.zeros((height, width), dtype=torch.uint8)
    # mask[y:y + h, x:x + w] = (scaled_mask[topcrop:topcrop + h,  leftcrop:leftcrop + w] > threshold)
    mask = torch.constant_pad_nd((scaled_mask[topcrop:topcrop + h, leftcrop:leftcrop + w] > threshold),
                                 (int(x), int(width - x - w), int(y), int(height - y - h)))   # int for the script compiler

    if contour:
        mask = mask.float()
        # poor person's contour finding by comparing to smoothed
        mask = (mask - torch.nn.functional.conv2d(mask.unsqueeze(0).unsqueeze(0),
                                                  torch.full((1, 1, 3, 3), 1.0 / 9.0), padding=1)[0, 0]).abs() > 0.001
    if rectangle:
        x = torch.arange(width, dtype=torch.long).unsqueeze(0)
        y = torch.arange(height, dtype=torch.long).unsqueeze(1)
        r = bbox.long()
        # work around script not liking bitwise ops
        rectangle_mask = ((((x == r[0]) + (x == r[2])) * (y >= r[1]) * (y <= r[3]))
                          + (((y == r[1]) + (y == r[3])) * (x >= r[0]) * (x <= r[2])))
        mask = (mask + rectangle_mask).clamp(max=1)
    return mask


@torch.jit.script
def add_annotations(image, labels, scores, bboxes, class_names: str=','.join(coco_demo.CATEGORIES), color=torch.tensor([255, 255, 255], dtype=torch.long)):
    result_image = torch.ops.maskrcnn_benchmark.add_annotations(image, labels, scores, bboxes, class_names, color)
    return result_image


@torch.jit.script
def combine_masks(image, labels, masks, scores, bboxes, threshold: float=0.5, padding: int=1, contour: bool=True, rectangle: bool=False, palette=torch.tensor([33554431, 32767, 2097151])):
    height = image.size(0)
    width = image.size(1)
    image_with_mask = image.clone()
    for i in range(masks.size(0)):
        color = ((palette * labels[i]) % 255).to(torch.uint8)
        one_mask = my_paste_mask(masks[i, 0], bboxes[i], height, width, threshold, padding, contour, rectangle)
        image_with_mask = torch.where(one_mask.unsqueeze(-1), color.unsqueeze(0).unsqueeze(0), image_with_mask)
    image_with_mask = add_annotations(image_with_mask, labels, scores, bboxes)
    return image_with_mask


def process_image_with_traced_model(image):
    original_image = image

    if coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY:
        assert (image.size(0) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0
                and image.size(1) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0)

    boxes, labels, masks, scores = traced_model(image)

    # todo: make this in one large thing
    result_image = combine_masks(original_image, labels, masks, scores, boxes, 0.5, 1, rectangle=True)
    return result_image
#origin 640,480
def prepareInputData(img_,size = image_size):

    if(img_.ndim == 2):
        cv2.cvtColor(img_,img_,cv2.COLOR_GRAY2RGB)


    img_= cv2.resize(img_,size)
    image = torch.from_numpy(numpy.array(img_)[:, :, [0, 1, 2]])
    image = image.float()
    return image.unsqueeze(0)

if __name__ == "__main__":
    # pil_image = Image.open(
    #     "/home/shining/Projects/datasets/Following/Validation-set/三人/2017-05-05-11-58-54_src6882.jpg").convert("RGB")
    # # convert to BGR format
    # pil_image = pil_image.resize((640, 480), Image.BILINEAR)
    # image = torch.from_numpy(numpy.array(pil_image)[:, :, [2, 1, 0]])
    # original_image = image
    # image=image.float()
    # image.to(device)
    # original_image.to(device)
    #
    # test_image = Image.open(
    #     "/home/shining/Projects/datasets/Following/Validation-set/三人/2017-05-05-11-58-54_src6959.jpg").convert("RGB")
    # # convert to BGR format
    # test_image = test_image.resize((640, 480), Image.BILINEAR)
    # test_image = torch.from_numpy(numpy.array(test_image)[:, :, [2, 1, 0]])
    #
    # test_image = test_image.float()
    # test_image.to(device)
    # 第一步，首先设置RPN_ONLY = True,即只跑RPN以上的模块，目前使用cuda进行Trace正常。
    #第二步，首先设置MASK_ON= False,即关闭Mask的head，发现报同样的错误，所以很有可能是Head模块的问题，查看代码发现错误。
    #
    #
    #
    #
    #
    image = cv2.imread("/home/shining/Projects/datasets/Xray/8.28/images/cut_pic_copy_1/I-160133_00000103_20170831_113959_00000401_001.jpg")

    # if coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY:
    #     assert (pil_image.size(0) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0
    #             and pil_image.size(1) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0)

    # convert to BGR format
    #目前支持多batch的infer
    image = prepareInputData(image)
    # image = torch.cat((image,image),0)

    test_image = cv2.imread("/home/shining/work/maskrcnn-shining/trace/2017-05-05-11-58-54_src6882.jpg")

    # if coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY:
    #     assert (pil_image.size(0) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0
    #             and pil_image.size(1) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0)

    # convert to BGR format
    test_image = prepareInputData(test_image)


    if coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY:
        assert (image.size(1) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0
                and image.size(2) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0)

    with torch.no_grad():
        traced_model = torch.jit.trace(single_image_to_top_predictions, (image.to(device),) )
        print(traced_model.graph)
        traced_model.save('Xray/model_single_image_to_top_predictions.pt')
    if cfg.TEST.USING_TensorRT:
        import torch
        torch.ops.maskrcnn_benchmark.destroy_tensorRT(0)
    # @torch.jit.script
    # def end_to_end_model(image):
    #     boxes, labels, masks, scores = traced_model(image)
    #     result_image = combine_masks(image.cpu(), labels.cpu(), masks.cpu(), scores.cpu(), boxes.cpu(), 0.5, 1, rectangle=True)
    #     return result_image
    # end_to_end_model.save('end_to_end_model.pt')
    #
    # result_image = process_image_with_traced_model(image)
    #
    # # self.show_mask_heatmaps not done
    # pyplot.imshow(result_image[:, :, [2, 1, 0]])
    # pyplot.show()
    #
    # # second image
    # image2 = Image.open('/home/shining/Projects/github-projects/pytorch-project/cpp-pytorch/Debug/image.jpg').convert("RGB")
    # image2 = image2.resize((640, 480), Image.BILINEAR)
    # image2 = torch.from_numpy(numpy.array(image2)[:, :, [2, 1, 0]])
    # result_image2 = process_image_with_traced_model(image2)
    #
    # # self.show_mask_heatmaps not done
    # pyplot.imshow(result_image2[:, :, [2, 1, 0]])
    # pyplot.show()
