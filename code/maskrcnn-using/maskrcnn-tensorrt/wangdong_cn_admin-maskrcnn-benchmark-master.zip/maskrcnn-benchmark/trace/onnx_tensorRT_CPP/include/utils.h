//
// Created by shining on 19-1-28.
//

#ifndef MASKRCNN_BENCHMARK_CPPDEMO_UTILS_H
#define MASKRCNN_BENCHMARK_CPPDEMO_UTILS_H
#include <torch/script.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>


namespace torch{
    // 输入：%x.1 : Float(1, 3, 480, 640)
    // 输出：return (%332, %328, %324, %320, %333);
    // %332 : Float(1, 64, 120, 160)
    // %328 : Float(1, 64, 60, 80)
    // %324 : Float(1, 64, 30, 40)
    // %320 : Float(1, 64, 15, 20)
    // %333 : Float(1, 64, 8, 10)
    // 怎么求？ 根据onnx打印输出的graph，可以看到输入shape还有输出的return的shape
    // TensorRT out
//    binding: x.1
//    size: 921600
//    dtype: <class 'numpy.float32'>
//    binding: 320
//    size: 19200
//    dtype: <class 'numpy.float32'>
//                  binding: 324
//    size: 76800
//    dtype: <class 'numpy.float32'>
//                  binding: 328
//    size: 307200
//    dtype: <class 'numpy.float32'>
//                  binding: 332
//    size: 1228800
//    dtype: <class 'numpy.float32'>
//                  binding: 333
//    size: 5120
//    dtype: <class 'numpy.float32'>
    static std::vector<int> FLAGS_Detect_OUTPUT_SIZE = {64*120*160,
                                                        64*(60*80 ),
                                                        64*( 30*40 ),
                                                        64*( 15*20 ),
                                                        64*(8*10)};
    static const int FLAGS_Detect_size_H = 480;
    static const int FLAGS_Detect_size_W = 640;
    static const int FLAGS_Detect_size_C =3;
    at::Tensor prepareInputData(cv::Mat img_, const at::TensorOptions& options);
    at::Tensor prepareInputData(cv::Mat img_);
}
#endif //MASKRCNN_BENCHMARK_CPPDEMO_UTILS_H
