//
// Created by shining on 19-1-28.
//

#include "utils.h"
namespace torch{
    at::Tensor prepareInputData(cv::Mat img_, const at::TensorOptions& options){
        //Mat m=Mat(rows, cols, type);
        //Mat m=Mat(Size(width,height), type);
        if(img_.channels() == 1){
            cv::cvtColor(img_,img_,cv::COLOR_GRAY2RGB);
        }

        cv::Mat img(cv::Size(FLAGS_Detect_size_W,FLAGS_Detect_size_H), CV_8UC3);
        cv::resize(img_, img, img.size(), 0, 0, cv::INTER_AREA);
//        img.convertTo(img, CV_32FC3);
        auto input_ = torch::tensor(at::ArrayRef<uint8_t >(img.data, img.rows * img.cols * 3)).view({img.rows, img.cols, 3});
        input_.to(options);
        return input_;
    }

    at::Tensor prepareInputData(cv::Mat img_){
        //Mat m=Mat(rows, cols, type);
        //Mat m=Mat(Size(width,height), type);
        if(img_.channels() == 1){
            cv::cvtColor(img_,img_,cv::COLOR_GRAY2RGB);
        }

        cv::Mat img(cv::Size(FLAGS_Detect_size_W,FLAGS_Detect_size_H), CV_8UC3);
        static const float kMean[3] = {102.9801, 115.9465, 122.7717};

        cv::resize(img_, img, img.size(), 0, 0, cv::INTER_AREA);
        float * data;
        data = (float*)calloc(img.rows*img.cols * 3, sizeof(float));
        for (int c = 0; c < 3; ++c)
        {
            for (int i = 0; i < img.rows; ++i)
            { //获取第i行首像素指针
                cv::Vec3b *p1 = img.ptr<cv::Vec3b>(i);
                //cv::Vec3b *p2 = image.ptr<cv::Vec3b>(i);
                for (int j = 0; j < img.cols; ++j)
                {
                    data[c * img.cols * img.rows + i * img.rows + j] = (p1[j][c]  - kMean[c]) ;
                }
            }
        }
//        img.convertTo(img, CV_32FC3);
        auto input_ = torch::tensor(at::ArrayRef<uint8_t >(img.data, img.rows * img.cols * 3)).view({img.rows, img.cols, 3});
        return input_;
    }

//    float* prepareInputData(cv::Mat img_){
//        //Mat m=Mat(rows, cols, type);
//        //Mat m=Mat(Size(width,height), type);
//        if(img_.channels() == 1){
//            cv::cvtColor(img_,img_,cv::COLOR_GRAY2RGB);
//        }
//
//        cv::Mat img(cv::Size(FLAGS_Detect_size_W,FLAGS_Detect_size_H), CV_8UC3);
//        static const float kMean[3] = {102.9801, 115.9465, 122.7717};
//        float * data;
//        cv::resize(img_, img, img.size(), 0, 0, cv::INTER_AREA);
//        data = (float*)calloc(img.rows*img.cols * 3, sizeof(float));
//        for (int c = 0; c < 3; ++c)
//        {
//            for (int i = 0; i < img.rows; ++i)
//            { //获取第i行首像素指针
//                cv::Vec3b *p1 = img.ptr<cv::Vec3b>(i);
//                //cv::Vec3b *p2 = image.ptr<cv::Vec3b>(i);
//                for (int j = 0; j < img.cols; ++j)
//                {
//                    data[c * img.cols * img.rows + i * img.rows + j] = (p1[j][c]  - kMean[c]) ;
//                }
//            }
//        }
//
////        img.convertTo(img, CV_32FC3);
//
//        return data;
//    }
}