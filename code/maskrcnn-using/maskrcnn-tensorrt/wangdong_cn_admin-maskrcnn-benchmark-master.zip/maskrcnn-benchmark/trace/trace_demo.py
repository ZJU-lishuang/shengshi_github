# Using Jit and not using Jit compare 
import torch

from time import time
import numpy
import cv2

torch.ops.load_library("/home/shining/Projects/work/maskrcnn-xray/build/lib.linux-x86_64-3.6/maskrcnn_benchmark/lib/libmaskrcnn_benchmark_customops.so")

CATEGORIES = [
    '__background__', 'bottle', 'camera', 'battery', 'tools','battery', 'tools','battery', 'tools','battery', 'tools','battery', 'tools','battery', 'tools','battery', 'tools','battery', 'tools','battery', 'tools','battery', 'tools',
]
confidence_threshold = 0.2
USING_TensorRT = 1
image_size=(800,960)#(576,416)
if USING_TensorRT:
    enginePath = "/home/shining/work/maskrcnn-shining/trace/Xray/backbone.trt"
    channel = 3
    height = image_size[1]
    weight = image_size[0]
    torch.ops.maskrcnn_benchmark.init_backbone_tensorRT(enginePath , channel ,height ,weight)

def overlay_class_names(image, scores,labels ,boxes):


    labels = [CATEGORIES[i] for i in labels]


    template = "{}: {:.2f}"
    for box, score, label in zip(boxes, scores, labels):
        x, y = box[:2]
        s = template.format(label, score)
        cv2.putText(
            image, s, (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2
        )
    return image

def overlay_annotations( image, labels, boxes, ratio_w, ratio_h):
    for box, idx in zip(boxes, labels):
        y1 = box[1] /ratio_h;
        x1 = box[0] /ratio_w;
        y2 = box[3] /ratio_h;
        x2 = box[2] /ratio_w;
        x1 = x1.to(torch.int64)
        y1 = y1.to(torch.int64)
        x2 = x2.to(torch.int64)
        y2 = y2.to(torch.int64)
        top_left = (x1,y1)
        bottom_right = (x2,y2)

        image = cv2.rectangle(
            image, tuple(top_left), tuple(bottom_right), (0, 0, 255), 8
        )

    return image

#Size(width  ,height)
def prepareInputData(img_,size = image_size ):
    ratio_h = size[1] / float(img_.shape[0]);

    ratio_w = size[0] / float(img_.shape[1]);
    if(img_.ndim == 2):
        cv2.cvtColor(img_,img_,cv2.COLOR_GRAY2RGB)

    img_= cv2.resize(img_,size)
    image = torch.from_numpy(numpy.array(img_)[:, :, [0, 1, 2]])
    image = image.float()

    return image.unsqueeze(0), ratio_w, ratio_h



# Use torch.jit.trace to generate a torch.jit.ScriptModule via tracing.
traced_script_module = torch.jit.load("/home/shining/work/maskrcnn-shining/trace/Xray/model_single_image_to_top_predictions.pt",map_location=torch.device('cuda:0'))#
print(traced_script_module.graph)
# traced_script_module.eval()
device = torch.device('cpu' if torch.cuda.is_available() else 'cuda:0')
#device = torch.device('cpu')
traced_script_module.cuda()



image=cv2.imread("/home/shining/Projects/datasets/Xray/images/train/20180508/180508_150118_00016046.jpg")

# if coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY:
#     assert (pil_image.size(0) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0
#             and pil_image.size(1) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0)

# convert to BGR format
original_image = image
image,ratio_w, ratio_h = prepareInputData(image)
# image = torch.cat((image,image),0)



# evalute time
for i in range(10):                 
    start = time()
    # output = traced_script_module(image)
    results  = traced_script_module(image.to(device))# ,boxes, labels, masks
    stop = time()
    print(str(stop-start) + "s")
    num_pic = len(results) / 3
    for j in range(int(num_pic)):
        scores = results[j*3]
        boxes = results[j*3 +1]
        labels = results[j*3 +2]
        keep = (scores >= confidence_threshold)
        scores = scores[keep]
        boxes = boxes[keep]
        labels = labels[keep]


    #    masks = masks[keep]
        #result = traced_script_module(image.to(device))
        result_image = overlay_annotations(original_image, labels.cpu(),  boxes.cpu(), ratio_w, ratio_h)
        result = overlay_class_names(result_image, scores,labels,boxes )

        #### 下面的代码可以实现可视化。
        cv2.imshow("test",result)
        cv2.waitKey(0)

if USING_TensorRT:
    import torch
    torch.ops.maskrcnn_benchmark.destroy_tensorRT(0)