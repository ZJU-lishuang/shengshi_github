# Using Jit and not using Jit compare 
import torch
import torchvision
from torchvision import transforms
from PIL import Image
from time import time
import numpy
from matplotlib import pyplot
from trace_model import combine_masks,coco_demo


# Use torch.jit.trace to generate a torch.jit.ScriptModule via tracing.
traced_script_module = torch.jit.load("model_single_image_to_top_predictions.pt",map_location=torch.device('cuda:0'))#
print(traced_script_module.graph)
# traced_script_module.eval()
device = torch.device('cpu' if torch.cuda.is_available() else 'cuda:0')
#device = torch.device('cpu')
traced_script_module.cuda()
pil_image = Image.open(
    "/home/shining/Projects/datasets/Train_data_new/2018_01_11/JPEGImages/image_2018_01_11_01_1.jpg").convert("RGB")
# 640*480 ,width,height
pil_image = pil_image.resize((384, 288), Image.BILINEAR)

# if coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY:
#     assert (pil_image.size(0) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0
#             and pil_image.size(1) % coco_demo.cfg.DATALOADER.SIZE_DIVISIBILITY == 0)

# convert to BGR format
image = torch.from_numpy(numpy.array(pil_image)[:, :, [2, 1, 0]])
original_image = image


# evalute time
for i in range(10):                 
    start = time()
    # output = traced_script_module(image)
    scores  = traced_script_module(image.to(device))# ,boxes, labels, masks
    # keep = (scores >= coco_demo.confidence_threshold)
    # scores = scores[keep]
    # boxes = boxes[keep]
    # labels = labels[keep]
#    masks = masks[keep]
    #result = traced_script_module(image.to(device))
    #result_image = combine_masks(image.cpu(), labels.cpu(), masks.cpu(), scores.cpu(), boxes.cpu(), 0.5, 1, rectangle=True)
    #### 下面的代码可以实现可视化。
    # pyplot.imshow(result_image[:, :, [2, 1, 0]])
    # pyplot.show()
    stop = time()
    print(str(stop-start) + "s")