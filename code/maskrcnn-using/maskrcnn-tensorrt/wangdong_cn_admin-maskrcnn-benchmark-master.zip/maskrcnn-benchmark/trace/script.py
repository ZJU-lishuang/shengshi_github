import torch
@torch.jit.script
def x(a):
     a=a[:]
     return a.abs()*2
#x(torch.randn(5, device='cuda'))
traced_model = torch.jit.trace(x,(torch.randn(5, device='cuda')))
traced_model(torch.randn(5, device='cuda'))


# def test_masked_fill():
#
#      def f(y, mask):
#         return y.clone().masked_fill_(mask, 0.)
#
#      x = torch.tensor([-float('inf'), -1., 0., 1., float('inf')])
#      y = x / x.unsqueeze(-1)
#      mask = ~(y == y)
#      f = torch.jit.trace(f, (y, mask))
#
# test_masked_fill()