import matplotlib.pyplot as plt

from PIL import Image
import os
import shutil
import json
from io import BytesIO
import cv2
import numpy as np
import argparse
# this makes our figures bigger


from maskrcnn_benchmark.config import cfg
from predictor_Xray import XrayDetector

IMG_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.ppm', '.bmp', '.pgm']
def is_image_file(filename):
    """Checks if a file is an image.
      Args:
          filename (string): path to a file
      Returns:
          bool: True if the filename ends with a known image extension
    """
    filename_lower = filename.lower()
    return any(filename_lower.endswith(ext) for ext in IMG_EXTENSIONS)


def get_imagelist_from_dir(dirpath):
    images = []
    for f in os.listdir(dirpath):
        if is_image_file(f):
            images.append(os.path.join(dirpath, f))
    return images

def parse_args():
    """Parse in command line arguments"""
    parser = argparse.ArgumentParser(description='Demonstrate mask-rcnn results')
    parser.add_argument(
        '--image_dir',
        dest='image_dir',
        default='/home/shining/Projects/work/detectron.pytorch/demo/sample_images',
        help='directory to load images for demo'
    )
    parser.add_argument(
        '--images', nargs='+',
        help='images to infer. Must not use with --image_dir')
    parser.add_argument(
        '--output_dir',
        help='directory to save demo results',
        default="vis_outputs")
    parser.add_argument(
        '--is_save_json',
        help='whether to save demo json results', type=bool,
        default=True)
    parser.add_argument(
        '--output_json_dir',
        help='directory to save demo json results',
        default="vis_outputs/json_results")
    return  parser.parse_args()

args = parse_args()
print('Called with args:')
print(args)

isExists = os.path.exists(args.output_dir)
if not isExists:
    os.mkdir(args.output_dir)

## output json formate 输出mask_anotation 能识别并显示的文件
isExists = os.path.exists(args.output_json_dir)
if args.is_save_json == True:
    if not isExists:
        os.mkdir(args.output_json_dir)
    else:
        shutil.rmtree(args.output_json_dir)
        os.mkdir(args.output_json_dir)




config_file = "/home/shining/Projects/work/maskrcnn-xray/configs/caffe2/e2e_mask_rcnn_R_50_C4_1x_caffe2.yaml"

# update the config options with the config file
cfg.merge_from_file(config_file)
# manual override some options
cfg.merge_from_list(["MODEL.DEVICE", "cpu"])

detector = XrayDetector(
    cfg,
    confidence_threshold=0.7,
    show_mask_heatmaps=False,
    masks_per_dim=2,
    min_image_size=480,
    save_json = args.is_save_json
)


if args.image_dir:
    imglist = get_imagelist_from_dir(args.image_dir)
else:
    imglist = args.images
num_images = len(imglist)
if not os.path.exists(args.output_dir):
    os.makedirs(args.output_dir)

for i in range(num_images):
    print('img:', imglist[i])


    # # from http://cocodataset.org/#explore?id=345434
   # pil_image = Image.open(imglist[i]).convert("RGB")
    # if cfg.DATALOADER.SIZE_DIVISIBILITY:
    #     assert (image.size(0) % cfg.DATALOADER.SIZE_DIVISIBILITY == 0
    #             and image.size(1) % cfg.DATALOADER.SIZE_DIVISIBILITY == 0)
    # convert to BGR format
   # image = np.array(pil_image)[:, :, [2, 1, 0]]
    image=cv2.imread(imglist[i])
    #
    # compute predictions
    predictions,dict_list = detector.run_on_opencv_image(image)
    # save result images

    output_name = os.path.basename(imglist[i]).strip('.jpg') + '.' + "jpg"
    cv2.imwrite(os.path.join(args.output_dir, '{}'.format(output_name)), predictions)
    if args.is_save_json:


        output_namej = os.path.basename(imglist[i]).strip('.jpg') + '.json'

        jsPath = os.path.join(args.output_json_dir, '{}'.format(output_namej))
        djson = {"filename": os.path.basename(imglist[i]),
                 "imgHeight": image.shape[0],
                 "imgWidth": image.shape[1],
                 "objects": dict_list
                 }

        with open(jsPath, "w") as f:
            json.dump(djson, f, sort_keys=True, indent=4)
        print("%s saved." % jsPath)