//
// Created by shining on 19-1-28.
//

#ifndef MASKRCNN_BENCHMARK_CPPDEMO_UTILS_H
#define MASKRCNN_BENCHMARK_CPPDEMO_UTILS_H
#include <torch/script.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>

#include "caffe2/core/timer.h"

namespace torch{
    const int FLAGS_Detect_size_H = 416;
    const int FLAGS_Detect_size_W = 576;
    at::Tensor prepareInputData(cv::Mat img_, const at::TensorOptions& options);
    at::Tensor prepareInputData(cv::Mat img_ , bool isCPU);
}
#endif //MASKRCNN_BENCHMARK_CPPDEMO_UTILS_H
