//
// Created by shining on 19-1-29.
//

#include "visualize.h"

#include <string>
#include <vector>

// COCO Class names
// Index of the class in the list is its ID. For example, to get ID of
// the teddy bear class, use: class_names.index("teddy bear")
//static std::vector<std::string> class_names = {"BG",
//                                               "person",
//                                               "bicycle",
//                                               "car",
//                                               "motorcycle",
//                                               "airplane",
//                                               "bus",
//                                               "train",
//                                               "truck",
//                                               "boat",
//                                               "traffic light",
//                                               "fire hydrant",
//                                               "stop sign",
//                                               "parking meter",
//                                               "bench",
//                                               "bird",
//                                               "cat",
//                                               "dog",
//                                               "horse",
//                                               "sheep",
//                                               "cow",
//                                               "elephant",
//                                               "bear",
//                                               "zebra",
//                                               "giraffe",
//                                               "backpack",
//                                               "umbrella",
//                                               "handbag",
//                                               "tie",
//                                               "suitcase",
//                                               "frisbee",
//                                               "skis",
//                                               "snowboard",
//                                               "sports ball",
//                                               "kite",
//                                               "baseball bat",
//                                               "baseball glove",
//                                               "skateboard",
//                                               "surfboard",
//                                               "tennis racket",
//                                               "bottle",
//                                               "wine glass",
//                                               "cup",
//                                               "fork",
//                                               "knife",
//                                               "spoon",
//                                               "bowl",
//                                               "banana",
//                                               "apple",
//                                               "sandwich",
//                                               "orange",
//                                               "broccoli",
//                                               "carrot",
//                                               "hot dog",
//                                               "pizza",
//                                               "donut",
//                                               "cake",
//                                               "chair",
//                                               "couch",
//                                               "potted plant",
//                                               "bed",
//                                               "dining table",
//                                               "toilet",
//                                               "tv",
//                                               "laptop",
//                                               "mouse",
//                                               "remote",
//                                               "keyboard",
//                                               "cell phone",
//                                               "microwave",
//                                               "oven",
//                                               "toaster",
//                                               "sink",
//                                               "refrigerator",
//                                               "book",
//                                               "clock",
//                                               "vase",
//                                               "scissors",
//                                               "teddy bear",
//                                               "hair drier",
//                                               "toothbrush"};

//static std::vector<std::string> class_names = {"BG",
//                                               "handgun",
//                                               "knife",
//                                               "small knife",
//                                               "tools"};

static std::vector<std::string> class_names = {"BG",
                                               "miss_sanding",
                                               "black_spot",
                                               "white_spot",
                                               "crude_paring","white_miss_sanding","deficient_edge","crack"};

void visualize(const cv::Mat& image,
               at::Tensor boxes,
               at::Tensor class_ids,
               at::Tensor scores,
               at::Tensor masks,float ratio_w = 1.0,float ratio_h = 1.0) {
    cv::Mat img = image.clone();
    auto n = boxes.size(0);
    for (int64_t i = 0; i < n; ++i) {
        auto bbox = boxes[i];
        //top_left, bottom_right = box[:2].tolist(), box[2:].tolist()
        auto y1 = *bbox[1].data<float>() /ratio_h;
        auto x1 = *bbox[0].data<float>() /ratio_w;
        auto y2 = *bbox[3].data<float>() /ratio_h;
        auto x2 = *bbox[2].data<float>() /ratio_w;
        auto class_id = *class_ids[i].data<int64_t>();
        auto score = *scores[i].data<float>();

//        cv::Mat bin_mask = masks[i].clone();
//        cv::Mat mask_ch[3];
//        mask_ch[2] = bin_mask;
//        mask_ch[0] = cv::Mat::zeros(img.size(), CV_8UC1);
//        mask_ch[1] = cv::Mat::zeros(img.size(), CV_8UC1);
//        cv::Mat mask;
//        cv::merge(mask_ch, 3, mask);
//        cv::addWeighted(img, 1, mask, 0.5, 0, img);
		std::cout << class_names[static_cast<size_t>(class_id)] + " - " +
			std::to_string(score) << std::endl;
        cv::Point tl(static_cast<int>(x1), static_cast<int>(y1));
        cv::Point br(static_cast<int>(x2), static_cast<int>(y2));
        cv::rectangle(img, tl, br, cv::Scalar(1, 0, 0));
        cv::putText(img,
                    class_names[static_cast<size_t>(class_id)] + " - " +
                    std::to_string(score),
                    cv::Point(tl.x + 5, tl.y + 5),   // Coordinates
                    cv::FONT_HERSHEY_COMPLEX_SMALL,  // Font
                    1.0,                             // Scale. 2.0 = 2x bigger
                    cv::Scalar(255, 100, 255));      // BGR Color
    }
    cv::imwrite("result.png", img);
}