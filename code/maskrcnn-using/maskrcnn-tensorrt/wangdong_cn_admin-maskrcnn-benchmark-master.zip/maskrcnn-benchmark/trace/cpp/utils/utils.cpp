//
// Created by shining on 19-1-28.
//

#include "utils.h"
namespace torch{
    at::Tensor prepareInputData(cv::Mat img_, const at::TensorOptions& options){
        //Mat m=Mat(rows, cols, type);
        //Mat m=Mat(Size(width,height), type);
        if(img_.channels() == 1){

            cv::cvtColor(img_,img_,cv::COLOR_GRAY2RGB);
        }

        cv::Mat img(cv::Size(FLAGS_Detect_size_W,FLAGS_Detect_size_H), CV_8UC3);
        cv::resize(img_, img, img.size(), 0, 0, cv::INTER_AREA);
//        img.convertTo(img, CV_32FC3);
        auto temp_tensor = torch::tensor(at::ArrayRef<uint8_t >(img.data, img.rows * img.cols * 3),options).view({1,img.rows, img.cols, 3});
//        input_.to(options);
//        return input_;
//        auto temp_tensor = torch::from_blob(img.data,{1,img.rows, img.cols, 3},options);
        return temp_tensor;
    }

    at::Tensor prepareInputData(cv::Mat img_ , bool isCPU){
        //Mat m=Mat(rows, cols, type);
        //Mat m=Mat(Size(width,height), type);
        if(img_.channels() == 1){
            cv::cvtColor(img_,img_,cv::COLOR_GRAY2RGB);
        }

        cv::Mat img(cv::Size(FLAGS_Detect_size_W,FLAGS_Detect_size_H), CV_8UC3);
        cv::resize(img_, img, img.size(), 0, 0, cv::INTER_AREA);
//        img.convertTo(img, CV_32FC3);
        auto input_ = torch::tensor(at::ArrayRef<uint8_t >(img.data, img.rows * img.cols * 3)).view({img.rows, img.cols, 3});
        return input_.unsqueeze(0);
        //创建cpu类型的tensor,并把mat的data部分赋值进去
//        if (isCPU == true){
//
//            auto temp_tensor = torch::CPU(torch::kFloat32).tensorFromBlob(img.data,{1,img.rows, img.cols, 3});
//            return temp_tensor;
//        }
//        else
//        {
//            auto temp_tensor = torch::CUDA(torch::kFloat32).tensorFromBlob(img.data,{1,img.rows, img.cols, 3});
//            return temp_tensor;
//        }

    }
}