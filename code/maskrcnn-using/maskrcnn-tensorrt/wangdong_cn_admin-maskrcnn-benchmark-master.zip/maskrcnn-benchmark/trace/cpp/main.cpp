
#include <iostream>

//#include <dlfcn.h>
#include "utils.h"
#include "visualize.h"
#include <dlfcn.h>
#define Box_confidence_threshold 0.7

namespace torch{


  int jit_pretrained_run() {
//	  void* custom_op_lib = dlopen("maskrcnn_benchmark_customops.dll", RTLD_NOW | RTLD_GLOBAL);
//	  if (custom_op_lib == NULL) {
//		  std::cerr << "could not open custom op library: " << dlerror() << std::endl;
//		  return 1;
//	  }
   // load libmaskrcnn_benchmark_customops.so 使得主程序能够找到.pt 文件的代码
    void* custom_op_lib = dlopen("/home/shining/work/maskrcnn-shining/maskrcnn_benchmark/csrc/custom_ops/build/libmaskrcnn_benchmark_customops.so", RTLD_NOW | RTLD_GLOBAL);

    if (custom_op_lib == NULL) {
      std::cerr << "could not open custom op library: " << dlerror() << std::endl;
       return 1;
    }
    try {

// C++ load custom op并使用custom op
/*
 *
  auto& ops = torch::jit::getAllOperatorsFor(
  torch::jit::Symbol::fromQualString("custom::op"));
  assert(ops.size() == 1);

   auto& op = ops.front();
  assert(op->schema().name == "custom::op");

   torch::jit::Stack stack;
  torch::jit::push(stack, torch::ones(5), 2.0, 3);
  op->getOperation()(stack);
  std::vector<at::Tensor> output;
  torch::jit::pop(stack, output);
 *
 *
 *
 *
 *
 *
 */


        auto& ops = torch::jit::getAllOperatorsFor(
                torch::jit::Symbol::fromQualString("maskrcnn_benchmark::init_backbone_tensorRT"));
        assert(ops.size() == 1);

        auto& op = ops.front();
//        assert(op->schema_().name == "maskrcnn_benchmark::init_backbone_tensorRT");

        torch::jit::Stack stack;
        torch::jit::push(stack, std::string("/home/shining/work/maskrcnn-shining/tensorRT/backbone.trt"),3 , 480, 640);
        op->getOperation()(stack);
      auto image = cv::imread("/home/shining/work/maskrcnn-shining/trace/2017-05-05-11-58-54_src6882.jpg", cv::IMREAD_COLOR);
      if (image.empty()){
        std::cout << "can not open image..." << std::endl;
        return 1;
      }
        float ratio_h = FLAGS_Detect_size_H / float(image.rows);
        float ratio_w = FLAGS_Detect_size_W / float(image.cols);
        caffe2::Timer t;
        auto options =
                torch::TensorOptions()
                        .dtype(torch::kFloat32)
                        .layout(torch::kStrided)
                        .device(torch::kCUDA, 0)
                        ;
        std::shared_ptr<torch::jit::script::Module> module =
        torch::jit::load("/home/shining/work/maskrcnn-shining/trace/model_single_image_to_top_predictions.pt",c10::kCUDA);
        for (size_t times = 0;times < 10;times ++){
            t.Start();

//            at::Tensor input_= torch::prepareInputData(image,options);
            at::Tensor input_1= torch::prepareInputData(image , options);
            at::Tensor input_2= torch::prepareInputData(image , options);
            at::Tensor input = at::cat( at::TensorList{input_1,input_1}, 0); // 2 batch
            int batch = 2;
            std::vector<torch::jit::IValue> inputs;
            inputs.push_back(input);

            auto mid = t.MilliSeconds();
            std::cout<<"Detect with prepareInputData :"<< mid<<" ms"<<std::endl;
            c10::intrusive_ptr<c10::ivalue::Tuple> results = module->forward(inputs).toTuple();//.toTensor();
            std::cout<<"Detect with forward :"<<t.MilliSeconds() - mid <<" ms"<<std::endl;
            auto res = results->elements();
            std::vector<at::Tensor> latest_result;
            std::cout<<"Detect all :"<<t.MilliSeconds() <<" ms"<<std::endl;
            for (int i = 0; i < batch; ++i) {
                at::Tensor scores = res[i*3+0].toTensor();
                at::Tensor bboxes = res[i*3+1].toTensor();
                at::Tensor labels = res[i*3+2].toTensor();
                at::Tensor masks;
                if(res.size() > 3 ){
                    masks= res[3].toTensor();
                }
                auto  masked= at::gt(scores,Box_confidence_threshold);

                at::TensorList keep(masked);
                //std::cout<<"keep:"<<keep<<std::endl;
                at::Tensor scores_keep = scores.index(keep);
                //std::cout<<"scores_keep:"<<scores_keep<<std::endl;
                at::Tensor bboxes_keep = bboxes.index(keep);
                // std::cout<<"bboxes_keep:"<<bboxes_keep<<std::endl;
                at::Tensor labels_keep = labels.index(keep);
                //std::cout<<"labels_keep:"<<labels_keep<<std::endl;
                at::Tensor masks_keep;
                if(res.size() > 3 ) {
                    masks_keep = masks.index(keep);
                }
                //std::cout<<"masks_keep:"<<masks_keep<<std::endl;
                //方法二，在不知道数据长度的时候，可以直接将tensors存进vector中
                //      for (auto item:res) {
                //          latest_result.push_back(item.toTensor());
                //          at::print(item.toTensor());
                //      }

                //draw postprocess
                visualize(image, bboxes_keep.cpu(), labels_keep.cpu(),
                          scores_keep.cpu(),masks_keep.cpu(),ratio_w,ratio_h);

            }
//            at::Tensor scores = res[0].toTensor();
//            at::Tensor bboxes = res[1].toTensor();
//            at::Tensor labels = res[2].toTensor();
//            at::Tensor masks;
//            if(res.size() > 3 ){
//                masks= res[3].toTensor();
//            }
            /*
            *  boxes = boxes[boxes > box_thresh]
            */
            //Do postprocess
            //std::cout<<"scores before:"<<scores<<std::endl;


            //      cv::Mat cv_res(res.size(0), res.size(1), CV_8UC3, (void*) res.data<uint8_t>());
            //      cv::namedWindow("Detected", cv::WINDOW_AUTOSIZE);
            //      cv::imshow("Detected", cv_res);
        }
      //cv::waitKey(0);
      return 0;

    } catch(std::exception &e) {
    std::cout << "Throw exception: " << e.what() << "\n";
    }
  }

}
int main() {
  torch::jit_pretrained_run();
  return 0;
}
